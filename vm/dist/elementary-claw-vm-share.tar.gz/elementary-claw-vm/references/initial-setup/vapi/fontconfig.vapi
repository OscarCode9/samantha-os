/*
 * Minimal fontconfig VAPI for FcConfigAppFontAddDir
 * Used to register bundled fonts before GTK/Pango resolves font-family in CSS.
 */

[CCode (cheader_filename = "fontconfig/fontconfig.h")]
namespace Fc {
    [CCode (cname = "FcConfig", free_function = "")]
    [Compact]
    public class Config {
        [CCode (cname = "FcConfigGetCurrent")]
        public static unowned Config? get_current ();

        [CCode (cname = "FcConfigAppFontAddDir")]
        public bool app_font_add_dir ([CCode (type = "const FcChar8 *")] string dir);
    }

    [CCode (cname = "FcInitReinitialize")]
    public static bool init_reinitialize ();
}
