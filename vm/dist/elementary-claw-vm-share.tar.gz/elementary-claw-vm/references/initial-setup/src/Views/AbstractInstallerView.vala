/*
 * SPDX-License-Identifier: GPL-3.0-or-later
 * SPDX-FileCopyrightText: 2017-2024 elementary, Inc. (https://elementary.io)
 */

public abstract class AbstractInstallerView : Adw.NavigationPage {
    public signal void next_step ();

    protected Gtk.Box title_area;
    protected Gtk.Box content_area;
    protected Gtk.Box action_area;
    protected Gtk.Box split_box;

    construct {
        title_area = new Gtk.Box (VERTICAL, 12) {
            valign = CENTER
        };
        title_area.add_css_class (Granite.HeaderLabel.Size.H2.to_string ());

        content_area = new Gtk.Box (VERTICAL, 12);

        split_box = new Gtk.Box (HORIZONTAL, 12) {
            homogeneous = true,
            hexpand = true,
            vexpand = true,
        };
        split_box.append (title_area);
        split_box.append (content_area);

        action_area = new Gtk.Box (HORIZONTAL, 6) {
            halign = END,
            homogeneous = true
        };

        var main_box = new Gtk.Box (VERTICAL, 24) {
            margin_top = 12,
            margin_end = 12,
            margin_bottom = 12,
            margin_start = 12
        };
        main_box.append (split_box);
        main_box.append (action_area);

        child = main_box;
    }

    protected void configure_split_layout (bool homogeneous, int spacing = 12, int title_width = -1) {
        split_box.homogeneous = homogeneous;
        split_box.spacing = spacing;

        if (title_width > 0) {
            title_area.width_request = title_width;
        }
    }

    protected void configure_action_layout (bool homogeneous, int spacing = 6) {
        action_area.homogeneous = homogeneous;
        action_area.spacing = spacing;
    }
}
