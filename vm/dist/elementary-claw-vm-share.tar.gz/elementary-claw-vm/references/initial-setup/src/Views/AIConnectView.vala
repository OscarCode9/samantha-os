/*
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

public class Installer.AIConnectView : AbstractInstallerView {
    private enum Step {
        PRESENTATION,
        FORM,
        CONNECT,
        SUCCESS
    }
    private Step step = Step.PRESENTATION;
    private Gtk.Entry assistant_name_entry;
    private Gtk.Entry assistant_nature_entry;
    private Gtk.Entry assistant_vibe_entry;
    private Act.User created_user;
    private string created_user_name = "";
    private string created_user_real_name = "";
    private Gtk.Button connect_button;
    private Gtk.Button finish_button;
    private Gtk.Button open_browser_button;
    private Gtk.Button start_button;
    private Gtk.Box device_code_box;
    private Gtk.Box welcome_preview_box;
    private Gtk.Label welcome_preview_label;
    private Gtk.Label code_label;
    private Gtk.TextView soul_text_view;
    private Gtk.Label status_label;
    private Gtk.Spinner spinner;
    private Gtk.Entry preferred_user_name_entry;
    private Gtk.TextView user_context_text_view;
    private Gtk.Image hero_icon;
    private Gtk.Box state_indicator;
    private Gtk.Label state_label;
    private Gtk.Box card;
    private Gtk.Label step_counter;
    private Gtk.Box divider_line;
    private string verification_uri = "";


    public AIConnectView (Act.User created_user, string? created_user_name, string? created_user_real_name) {
        Object ();
        this.created_user = created_user;
        this.created_user_name = sanitize_user_text (created_user_name);
        this.created_user_real_name = sanitize_user_text (created_user_real_name);
        build_ui ();
        update_step (Step.PRESENTATION);
    }


    private Gtk.Box hero_box;
    private Gtk.Label title_label;
    private Gtk.Label subtitle_label;

    private void build_ui () {
        title = _( "Connect AI" );
        message (
            "AIConnectView build active: login=%s display=%s",
            created_user_name,
            get_created_user_display_name ()
        );
        split_box.homogeneous = false;
        split_box.orientation = VERTICAL;
        split_box.spacing = 0;
        title_area.visible = false;
        action_area.halign = CENTER;
        action_area.homogeneous = false;
        action_area.spacing = 16;

        hero_icon = new Gtk.Image.from_icon_name ( "preferences-system-network" ) {
            pixel_size = 36
        };
        hero_icon.add_css_class ( "ai-hero-icon" );

        title_label = new Gtk.Label ( _( "Welcome to elementary-claw" ) ) {
            halign = CENTER,
            justify = CENTER
        };
        title_label.add_css_class ( "ai-hero-title" );

        subtitle_label = new Gtk.Label ( _( "Meet your new AI assistant. Let's get you set up in a few simple steps." ) ) {
            halign = CENTER,
            justify = CENTER,
            max_width_chars = 52,
            wrap = true
        };
        subtitle_label.add_css_class ( "ai-hero-subtitle" );

        var state_dot = new Gtk.Box ( HORIZONTAL, 0 ) {
            width_request = 8,
            height_request = 8,
            valign = CENTER
        };
        state_dot.add_css_class ( "ai-state-dot" );
        state_dot.add_css_class ( "ai-state-waiting" );

        state_label = new Gtk.Label ( _( "Waiting to connect" ) ) {
            valign = CENTER
        };
        state_label.add_css_class ( "ai-state-label" );

        state_indicator = new Gtk.Box ( HORIZONTAL, 8 ) {
            halign = CENTER,
            margin_top = 4
        };
        state_indicator.append ( state_dot );
        state_indicator.append ( state_label );

        hero_box = new Gtk.Box ( VERTICAL, 8 ) {
            halign = CENTER,
            margin_bottom = 20
        };
        hero_box.add_css_class ( "ai-hero-box" );
        hero_box.append ( hero_icon );
        hero_box.append ( title_label );
        hero_box.append ( subtitle_label );
        hero_box.append ( state_indicator );

        /* ── Identity card ── */
        assistant_name_entry = new Gtk.Entry () {
            hexpand = true,
            text = "Claw",
            placeholder_text = _("e.g. Claw, Nova, Atlas")
        };
        assistant_name_entry.add_css_class ("ai-input");

        preferred_user_name_entry = new Gtk.Entry () {
            hexpand = true,
            text = get_created_user_display_name (),
            placeholder_text = _("Your name")
        };
        preferred_user_name_entry.add_css_class ("ai-input");

        assistant_nature_entry = new Gtk.Entry () {
            hexpand = true,
            text = _("A local AI teammate for this computer"),
            placeholder_text = _("What does the assistant do?")
        };
        assistant_nature_entry.add_css_class ("ai-input");

        assistant_vibe_entry = new Gtk.Entry () {
            hexpand = true,
            text = _("direct, warm, and pragmatic"),
            placeholder_text = _("Tone and personality")
        };
        assistant_vibe_entry.add_css_class ("ai-input");

        var fields_box = new Gtk.Box (VERTICAL, 20) {
            hexpand = true
        };
        fields_box.append (build_field (_("Assistant name"), assistant_name_entry));
        fields_box.append (build_field (_("Your name"), preferred_user_name_entry));
        fields_box.append (build_field (_("Personality"), assistant_vibe_entry));

        /* ── Directives ── */
        soul_text_view = new Gtk.TextView () {
            accepts_tab = false,
            wrap_mode = WORD_CHAR
        };
        soul_text_view.buffer.text = _("Be helpful without filler. Take initiative, but ask before destructive or external actions.");
        soul_text_view.add_css_class ("ai-input");

        user_context_text_view = new Gtk.TextView () {
            accepts_tab = false,
            wrap_mode = WORD_CHAR
        };
        user_context_text_view.buffer.text = _("This is my personal machine. Help me get productive quickly and keep context organized.");
        user_context_text_view.add_css_class ("ai-input");

        var directives_box = new Gtk.Box (VERTICAL, 20) {
            margin_top = 4
        };
        directives_box.append (build_field (_("Behavior"), wrap_text_view (soul_text_view)));
        directives_box.append (build_field (_("Context"), wrap_text_view (user_context_text_view)));

        /* ── Card container (transparent — fields float on coral) ── */
        card = new Gtk.Box (VERTICAL, 24) {
            hexpand = true,
            width_request = 520
        };
        card.add_css_class ("ai-card");
        card.append (fields_box);
        card.append (directives_box);

        /* ── Device code section (hidden until connect) ── */
        spinner = new Gtk.Spinner () {
            halign = CENTER,
            visible = false
        };

        code_label = new Gtk.Label ("") {
            halign = CENTER,
            selectable = true
        };
        code_label.add_css_class ("ai-code");

        open_browser_button = new Gtk.Button.with_label (_("Open Browser")) {
            halign = CENTER
        };
        open_browser_button.add_css_class ("ai-link-button");
        open_browser_button.clicked.connect (launch_browser);

        status_label = new Gtk.Label ("") {
            halign = CENTER,
            justify = CENTER,
            max_width_chars = 48,
            wrap = true
        };
        status_label.add_css_class ("ai-status");

        var url_hint_label = new Gtk.Label ("github.com/login/device") {
            halign = CENTER,
            selectable = true
        };
        url_hint_label.add_css_class ("ai-url-hint");

        device_code_box = new Gtk.Box (VERTICAL, 12) {
            halign = CENTER,
            margin_top = 16,
            visible = false
        };
        device_code_box.add_css_class ("ai-code-card");
        device_code_box.append (new Gtk.Label (_("Enter this code on GitHub")) {
            halign = CENTER
        });
        device_code_box.append (code_label);
        device_code_box.append (url_hint_label);
        device_code_box.append (open_browser_button);

        /* ── Welcome preview (shown after success) ── */
        welcome_preview_label = new Gtk.Label ("") {
            halign = CENTER,
            justify = CENTER,
            max_width_chars = 48,
            wrap = true
        };
        welcome_preview_label.add_css_class ("ai-preview");

        welcome_preview_box = new Gtk.Box (VERTICAL, 8) {
            halign = CENTER,
            margin_top = 16,
            visible = false
        };
        welcome_preview_box.add_css_class ("ai-preview-card");
        welcome_preview_box.append (welcome_preview_label);

        /* ── Assemble main layout ── */

        /* Step counter + divider */
        step_counter = new Gtk.Label ("") {
            halign = CENTER,
            margin_bottom = 8
        };
        step_counter.add_css_class ("ai-step-counter");

        divider_line = new Gtk.Box (HORIZONTAL, 0) {
            hexpand = true,
            height_request = 1
        };
        divider_line.add_css_class ("ai-divider");

        var center_box = new Gtk.Box (VERTICAL, 0) {
            halign = CENTER,
            valign = CENTER,
            hexpand = true,
            vexpand = true,
            margin_start = 56,
            margin_end = 56,
            margin_top = 36,
            margin_bottom = 12
        };
        center_box.append (step_counter);
        center_box.append (hero_box);
        center_box.append (divider_line);
        center_box.append (card);
        center_box.append (device_code_box);
        center_box.append (welcome_preview_box);
        center_box.append (spinner);
        center_box.append (status_label);

        /* ── Presentation elements (Her-inspired, reuses hero_box) ── */
        start_button = new Gtk.Button.with_label (_("Comenzar")) {
            halign = CENTER
        };
        start_button.add_css_class ("ai-presentation-btn");
        start_button.clicked.connect (() => update_step (Step.FORM));

        center_box.append (start_button);

        var scroller = new Gtk.ScrolledWindow () {
            hexpand = true,
            vexpand = true,
            propagate_natural_width = true
        };
        scroller.set_policy (Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC);
        scroller.child = center_box;

        content_area.hexpand = true;
        content_area.vexpand = true;
        content_area.append (scroller);

        /* ── Action buttons ── */
        finish_button = new Gtk.Button.with_label (_("Skip"));
        finish_button.add_css_class ("ai-secondary-btn");
        finish_button.clicked.connect (() => Application.get_default ().quit ());

        connect_button = new Gtk.Button.with_label (_("Connect with GitHub")) {
            receives_default = true
        };
        connect_button.add_css_class ("ai-primary-btn");
        connect_button.clicked.connect (() => start_connect.begin ());

        action_area.append (finish_button);
        action_area.append (connect_button);
    }

    // Step logic: show/hide sections and buttons
    private void update_step (Step new_step) {
        step = new_step;
        if (step == Step.PRESENTATION) {
            /* Cinematic intro — just typography on coral */
            split_box.add_css_class ("ai-presentation");
            step_counter.visible = false;
            divider_line.visible = false;
            hero_icon.visible = false;
            title_label.label = "Hello.";
            title_label.remove_css_class ("ai-hero-title");
            title_label.add_css_class ("ai-presentation-title");
            subtitle_label.label = _("I'm Claw, your AI assistant.");
            subtitle_label.remove_css_class ("ai-hero-subtitle");
            subtitle_label.add_css_class ("ai-presentation-subtitle");
            state_indicator.visible = false;
            hero_box.visible = true;
            start_button.visible = true;
            card.visible = false;
            finish_button.visible = false;
            connect_button.visible = false;
            device_code_box.visible = false;
            welcome_preview_box.visible = false;
            spinner.visible = false;
            status_label.visible = false;
        } else if (step == Step.FORM) {
            /* Form — fields float naked on coral */
            split_box.remove_css_class ("ai-presentation");
            step_counter.visible = true;
            step_counter.label = "01 / 03";
            divider_line.visible = true;
            hero_icon.visible = true;
            title_label.label = _("Craft.");
            title_label.remove_css_class ("ai-presentation-title");
            title_label.add_css_class ("ai-hero-title");
            subtitle_label.label = _("Shape who Claw is and how it thinks.");
            subtitle_label.remove_css_class ("ai-presentation-subtitle");
            subtitle_label.add_css_class ("ai-hero-subtitle");
            state_indicator.visible = true;
            hero_box.visible = true;
            start_button.visible = false;
            card.visible = true;
            finish_button.visible = true;
            connect_button.visible = true;
            device_code_box.visible = false;
            welcome_preview_box.visible = false;
            spinner.visible = false;
            status_label.visible = false;
        } else if (step == Step.CONNECT) {
            /* Authorize — device code as hero element */
            step_counter.label = "02 / 03";
            divider_line.visible = true;
            hero_icon.visible = false;
            title_label.label = _("Authorize.");
            subtitle_label.label = _("Sign in with GitHub to activate Claw.");
            hero_box.visible = true;
            start_button.visible = false;
            card.visible = false;
            finish_button.visible = true;
            connect_button.visible = false;
            device_code_box.visible = true;
            welcome_preview_box.visible = false;
            spinner.visible = true;
            status_label.visible = true;
        } else if (step == Step.SUCCESS) {
            /* Connected — cinematic finish */
            step_counter.label = "03 / 03";
            divider_line.visible = false;
            hero_icon.visible = true;
            title_label.label = _("Ready.");
            subtitle_label.label = _("Claw is configured and waiting for you.");
            hero_box.visible = true;
            start_button.visible = false;
            card.visible = false;
            finish_button.visible = true;
            connect_button.visible = false;
            device_code_box.visible = false;
            welcome_preview_box.visible = true;
            spinner.visible = false;
            status_label.visible = false;
        }
    }

    private async void start_connect () {
        var profile = build_onboarding_profile ();

        update_step (Step.CONNECT);
        connect_button.sensitive = false;
        spinner.visible = true;
        spinner.start ();
        status_label.label = _("Contacting GitHub…");

        /* Update state indicator */
        update_state (_("Connecting…"), "ai-state-progress");

        try {
            var device = yield OpenClawBootstrap.request_device_code ();

            verification_uri = device.verification_uri;
            code_label.label = device.user_code;
            device_code_box.visible = true;

            launch_browser ();

            status_label.label = _("Approve the request in your browser, then come back here.");
            update_state (_("Waiting for approval…"), "ai-state-progress");

            var access_token = yield OpenClawBootstrap.poll_for_access_token (
                device.device_code,
                device.interval,
                device.expires_in
            );

            try {
                OpenClawBootstrap.provision_user (
                    created_user,
                    access_token,
                    profile,
                    created_user_name,
                    created_user_real_name
                );
            } catch (Error e) {
                spinner.stop ();
                spinner.visible = false;
                connect_button.sensitive = true;
                status_label.label = _("Authorization succeeded but setup could not finish.");
                update_state (_("Setup error"), "ai-state-error");

                show_connect_error (_("Unable to finish setup"), e.message);
                return;
            }

            spinner.stop ();
            spinner.visible = false;
            device_code_box.visible = false;
            connect_button.label = _("Connected");
            connect_button.sensitive = false;
            finish_button.label = _("Continue");
            finish_button.add_css_class ("ai-primary-btn");
            finish_button.add_css_class (Granite.CssClass.SUGGESTED);
            welcome_preview_label.label = build_welcome_preview (profile);
            welcome_preview_box.visible = true;
            status_label.label = "";

            update_state (_("Connected"), "ai-state-success");

            /* Change icon to checkmark */
            hero_icon.icon_name = "process-completed";
            hero_icon.add_css_class ("ai-hero-success");

        } catch (Error e) {
            spinner.stop ();
            spinner.visible = false;
            connect_button.sensitive = true;
            status_label.label = _("Could not connect. You can try again or skip this step.");
            update_state (_("Not connected"), "ai-state-error");

            show_connect_error (_("Unable to connect"), e.message);
        }
    }

    private void update_state (string text, string css_class) {
        state_label.label = text;

        /* Update dot color */
        var dot = state_indicator.get_first_child ();
        if (dot != null) {
            dot.remove_css_class ("ai-state-waiting");
            dot.remove_css_class ("ai-state-progress");
            dot.remove_css_class ("ai-state-success");
            dot.remove_css_class ("ai-state-error");
            dot.add_css_class (css_class);
        }
    }

    private void launch_browser () {
        if (verification_uri == "") {
            return;
        }

        /* Running as root — UriLauncher/portal won't work.
         * Spawn browser directly, as the real user if we're under sudo. */
        launch_browser_fallback ();
    }

    private void launch_browser_fallback () {
        string? real_user = Environment.get_variable ("SUDO_USER");
        bool as_other_user = (real_user != null && real_user != "" && Posix.getuid () == 0);

        if (!as_other_user) {
            /* Not running under sudo \u2014 simple direct launch */
            try {
                Process.spawn_command_line_async ("xdg-open " + Shell.quote (verification_uri));
            } catch (Error e) {
                warning ("xdg-open failed: %s", e.message);
            }
            return;
        }

        /* Running as root via sudo.  We must give the child process the
         * real user\u2019s full session environment so that xdg-open can
         * talk to D-Bus and launch Flatpak apps (elementary OS 8 ships
         * its browser as a Flatpak). */
        string? display  = Environment.get_variable ("DISPLAY");
        string? xauth    = Environment.get_variable ("XAUTHORITY");
        string? sudo_uid = Environment.get_variable ("SUDO_UID");

        var env = new StringBuilder ();
        env.append ("DISPLAY=" + (display ?? ":0"));
        if (xauth != null && xauth != "") {
            env.append (" XAUTHORITY=" + xauth);
        }
        /* DBUS_SESSION_BUS_ADDRESS + XDG_RUNTIME_DIR are critical for
         * Flatpak browsers.  sudo sets SUDO_UID for us. */
        if (sudo_uid != null && sudo_uid != "") {
            string runtime = "/run/user/" + sudo_uid;
            env.append (" XDG_RUNTIME_DIR=" + runtime);
            env.append (" DBUS_SESSION_BUS_ADDRESS=unix:path=" + runtime + "/bus");
        }

        string[] browsers = {
            "xdg-open",
            "epiphany",
            "epiphany-browser",
            "firefox",
            "chromium-browser",
            "google-chrome"
        };

        foreach (string browser in browsers) {
            string inner = env.str + " " + browser + " " + verification_uri;
            string cmd = "sudo -u " + Shell.quote (real_user)
                         + " bash -c " + Shell.quote (inner);
            warning ("Trying: %s", cmd);
            try {
                Process.spawn_command_line_async (cmd);
                return;
            } catch (Error e) {
                warning ("spawn failed for %s: %s", browser, e.message);
            }
        }

        warning ("No browser found. User must visit %s manually.", verification_uri);
    }

    private void show_connect_error (string primary_text, string? error_message = null) {
        var error_dialog = new Granite.MessageDialog.with_image_from_icon_name (
            primary_text,
            _("Could not complete GitHub sign-in for this account."),
            "dialog-error",
            Gtk.ButtonsType.CLOSE
        ) {
            modal = true,
            transient_for = (Gtk.Window) get_root ()
        };

        if (error_message != null) {
            error_dialog.show_error_details (error_message);
        }

        error_dialog.present ();
        error_dialog.response.connect (error_dialog.destroy);
    }

    private Gtk.Widget build_field (string label_text, Gtk.Widget widget) {
        var box = new Gtk.Box (VERTICAL, 4) {
            hexpand = true
        };

        var label = new Gtk.Label (label_text) {
            halign = START,
            xalign = 0
        };
        label.add_css_class ("ai-field-label");

        box.append (label);
        box.append (widget);

        return box;
    }

    private Gtk.Widget wrap_text_view (Gtk.TextView text_view) {
        var scrolled_window = new Gtk.ScrolledWindow () {
            hexpand = true,
            min_content_height = 64,
            propagate_natural_height = true
        };
        scrolled_window.add_css_class ("ai-text-frame");
        scrolled_window.set_policy (Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC);
        scrolled_window.child = text_view;

        return scrolled_window;
    }

    private Installer.OpenClawOnboardingProfile build_onboarding_profile () {
        var assistant_name = normalize_entry_text (assistant_name_entry.text, "Claw");
        var assistant_nature = normalize_entry_text (
            assistant_nature_entry.text,
            _("A local AI teammate for this computer")
        );
        var assistant_vibe = normalize_entry_text (
            assistant_vibe_entry.text,
            _("direct, warm, and pragmatic")
        );
        var preferred_user_name = normalize_entry_text (
            preferred_user_name_entry.text,
            get_created_user_display_name ()
        );

        return new Installer.OpenClawOnboardingProfile (
            assistant_name,
            assistant_nature,
            assistant_vibe,
            preferred_user_name,
            get_text_view_text (soul_text_view),
            get_text_view_text (user_context_text_view)
        );
    }

    private string get_text_view_text (Gtk.TextView text_view) {
        Gtk.TextIter start;
        Gtk.TextIter end;
        var buffer = text_view.buffer;
        buffer.get_bounds (out start, out end);
        return buffer.get_text (start, end, false).strip ();
    }

    private static string sanitize_user_text (string? value) {
        return value ?? "";
    }

    private string get_created_user_display_name () {
        var preferred_name = created_user_real_name.strip ();
        if (preferred_name != "") {
            return preferred_name;
        }

        var login_name = created_user_name.strip ();
        if (login_name != "") {
            return login_name;
        }

        return _("User");
    }

    private string normalize_entry_text (string value, string fallback) {
        var trimmed = value.strip ();
        return trimmed != "" ? trimmed : fallback;
    }

    private string build_welcome_preview (Installer.OpenClawOnboardingProfile profile) {
        return _("Hey %s, I'm %s — your AI assistant on this machine. I'm online and ready to help. What should we start with?").printf (
            profile.preferred_user_name,
            profile.assistant_name
        );
    }
}
