/*
 * SPDX-License-Identifier: GPL-3.0-or-later
 * SPDX-FileCopyrightText: 2017-2023 elementary, Inc. (https://elementary.io)
 */

public class Installer.AccountView : AbstractInstallerView {
    public signal void account_ready (Act.User created_user, string user_name, string real_name);

    private Act.UserManager _user_manager = null;
    private Act.UserManager user_manager {
        get {
            if (_user_manager != null && _user_manager.is_loaded) {
                return _user_manager;
            }

            _user_manager = Act.UserManager.get_default ();
            return _user_manager;
        }
    }

    private Utils.HostnameInterface? hostname_iface = null;

    private Polkit.Permission? _permission = null;
    private Polkit.Permission? permission {
        get {
            if (_permission != null) {
                return _permission;
            }

            try {
                _permission = new Polkit.Permission.sync ("org.freedesktop.accounts.user-administration", new Polkit.UnixProcess (Posix.getpid ()));
            } catch (Error e) {
                critical (e.message);
            }

            return _permission;
        }
    }

    private ErrorRevealer confirm_entry_revealer;
    private ErrorRevealer pw_error_revealer;
    private ErrorRevealer username_error_revealer;
    private Gtk.Button finish_button;
    private Gtk.TextView realname_text_view;
    private Gtk.Entry confirm_entry;
    private Gtk.TextView username_text_view;
    private Gtk.Entry pw_entry;
    private Gtk.LevelBar pw_levelbar;
    private Gtk.TextView hostname_text_view;

    /* Manual validation flags (avoids Granite accessibility DBus crash) */
    private bool username_valid = false;
    private bool pw_valid = false;
    private bool confirm_valid = false;
    private bool hostname_valid = false;

    private uint announce_timeout_id;

    construct {
        title = _("Create an Account");

        /* ── Cinematic centered layout (like AIConnectView) ── */
        split_box.homogeneous = false;
        split_box.orientation = VERTICAL;
        split_box.spacing = 0;
        title_area.visible = false;
        action_area.halign = CENTER;
        action_area.homogeneous = false;
        action_area.spacing = 16;

        /* ── Hero section ── */
        var hero_icon = new Gtk.Image.from_icon_name ("system-users") {
            pixel_size = 36
        };
        hero_icon.add_css_class ("ai-hero-icon");

        var hero_title = new Gtk.Label (_("You.")) {
            halign = CENTER,
            justify = CENTER
        };
        hero_title.add_css_class ("ai-hero-title");

        var hero_subtitle = new Gtk.Label (_("Create your account to get started.")) {
            halign = CENTER,
            justify = CENTER,
            max_width_chars = 48,
            wrap = true
        };
        hero_subtitle.add_css_class ("ai-hero-subtitle");

        var hero_box = new Gtk.Box (VERTICAL, 8) {
            halign = CENTER,
            margin_bottom = 20
        };
        hero_box.add_css_class ("ai-hero-box");
        hero_box.append (hero_icon);
        hero_box.append (hero_title);
        hero_box.append (hero_subtitle);

        /* ── Form fields (TextView — same component as AIConnectView) ── */
        realname_text_view = new Gtk.TextView () {
            hexpand = true,
            accepts_tab = false,
            wrap_mode = WORD_CHAR
        };
        realname_text_view.add_css_class ("ai-input");

        username_text_view = new Gtk.TextView () {
            hexpand = true,
            accepts_tab = false,
            wrap_mode = WORD_CHAR
        };
        username_text_view.add_css_class ("ai-input");

        username_error_revealer = new ErrorRevealer (".");
        username_error_revealer.label_widget.add_css_class (Granite.CssClass.ERROR);

        pw_error_revealer = new ErrorRevealer (".");
        pw_error_revealer.label_widget.add_css_class (Granite.CssClass.WARNING);

        pw_entry = new Gtk.Entry () {
            input_purpose = PASSWORD,
            visibility = false,
            hexpand = true
        };
        pw_entry.add_css_class ("ai-input");

        pw_levelbar = new Gtk.LevelBar.for_interval (0.0, 100.0);
        pw_levelbar.set_mode (Gtk.LevelBarMode.CONTINUOUS);
        pw_levelbar.add_offset_value ("low", 30.0);
        pw_levelbar.add_offset_value ("middle", 50.0);
        pw_levelbar.add_offset_value ("high", 80.0);
        pw_levelbar.add_offset_value ("full", 100.0);

        confirm_entry = new Gtk.Entry () {
            input_purpose = PASSWORD,
            sensitive = false,
            visibility = false,
            hexpand = true
        };
        confirm_entry.add_css_class ("ai-input");

        confirm_entry_revealer = new ErrorRevealer (".");
        confirm_entry_revealer.label_widget.add_css_class (Granite.CssClass.ERROR);

        hostname_text_view = new Gtk.TextView () {
            hexpand = true,
            accepts_tab = false,
            wrap_mode = WORD_CHAR,
            sensitive = false
        };
        hostname_text_view.add_css_class ("ai-input");

        var hostname_hint = new Gtk.Label (_("Visible to other devices when sharing, e.g. with Bluetooth or over the network.")) {
            halign = START,
            xalign = 0,
            max_width_chars = 52,
            wrap = true
        };
        hostname_hint.add_css_class ("ai-field-hint");

        Utils.HostnameInterface.get_default.begin ((obj, res) => {
            try {
                hostname_iface = Utils.HostnameInterface.get_default.end (res);
                hostname_text_view.buffer.text = hostname_iface.get_either_hostname ();
                hostname_text_view.sensitive = true;
            } catch (Error e) {
                critical ("Unable to setup Hostname interface: %s", e.message);
            }
        });

        /* ── Build field groups ── */
        var pw_field_box = new Gtk.Box (VERTICAL, 4) { hexpand = true };
        var pw_field_label = new Gtk.Label (_("Password")) { halign = START, xalign = 0 };
        pw_field_label.add_css_class ("ai-field-label");
        pw_field_box.append (pw_field_label);
        pw_field_box.append (pw_entry);
        pw_field_box.append (pw_levelbar);
        pw_field_box.append (pw_error_revealer);

        var confirm_field_box = new Gtk.Box (VERTICAL, 4) { hexpand = true };
        var confirm_field_label = new Gtk.Label (_("Confirm Password")) { halign = START, xalign = 0 };
        confirm_field_label.add_css_class ("ai-field-label");
        confirm_field_box.append (confirm_field_label);
        confirm_field_box.append (confirm_entry);
        confirm_field_box.append (confirm_entry_revealer);

        var hostname_field_box = new Gtk.Box (VERTICAL, 4) { hexpand = true };
        var hostname_field_label = new Gtk.Label (_("Device name")) { halign = START, xalign = 0 };
        hostname_field_label.add_css_class ("ai-field-label");
        hostname_field_box.append (hostname_field_label);
        hostname_field_box.append (wrap_text_view (hostname_text_view));
        hostname_field_box.append (hostname_hint);

        var fields_box = new Gtk.Box (VERTICAL, 16) {
            hexpand = true
        };
        fields_box.append (build_field (_("Full Name"), wrap_text_view (realname_text_view)));
        fields_box.append (build_field_with_error (_("Username"), wrap_text_view (username_text_view), username_error_revealer));
        fields_box.append (pw_field_box);
        fields_box.append (confirm_field_box);
        fields_box.append (hostname_field_box);

        /* ── Card container ── */
        var card = new Gtk.Box (VERTICAL, 20) {
            hexpand = true,
            width_request = 460
        };
        card.add_css_class ("ai-card");
        card.append (fields_box);

        /* ── Divider ── */
        var divider_line = new Gtk.Box (HORIZONTAL, 0) {
            hexpand = true,
            height_request = 1
        };
        divider_line.add_css_class ("ai-divider");

        /* ── Center box ── */
        var center_box = new Gtk.Box (VERTICAL, 0) {
            halign = CENTER,
            valign = CENTER,
            hexpand = true,
            vexpand = true,
            margin_start = 56,
            margin_end = 56,
            margin_top = 36,
            margin_bottom = 12
        };
        center_box.append (hero_box);
        center_box.append (divider_line);
        center_box.append (card);

        var scroller = new Gtk.ScrolledWindow () {
            hexpand = true,
            vexpand = true,
            propagate_natural_width = true
        };
        scroller.set_policy (Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC);
        scroller.child = center_box;

        content_area.hexpand = true;
        content_area.vexpand = true;
        content_area.append (scroller);

        /* ── Action buttons ── */
        var back_button = new Gtk.Button.with_label (_("Back"));
        back_button.add_css_class ("back-button");

        finish_button = new Gtk.Button.with_label (_("Create Account")) {
            receives_default = true,
            sensitive = false
        };
        finish_button.add_css_class (Granite.CssClass.SUGGESTED);

        action_area.append (back_button);
        action_area.append (finish_button);

        back_button.clicked.connect (() => ((Adw.NavigationView) get_parent ()).pop ());

        realname_text_view.buffer.changed.connect (() => {
            var username = gen_username (realname_text_view.buffer.text);
            username_text_view.buffer.text = username;
        });

        username_text_view.buffer.changed.connect (() => {
            username_valid = check_username ();
            update_finish_button ();
        });

        pw_entry.changed.connect (() => {
            pw_valid = check_password ();
            confirm_valid = confirm_password ();
            update_finish_button ();
        });

        confirm_entry.changed.connect (() => {
            confirm_valid = confirm_password ();
            update_finish_button ();
        });

        hostname_text_view.buffer.changed.connect (() => {
            hostname_valid = check_hostname ();
            update_finish_button ();
        });

        finish_button.clicked.connect (apply_settings);
    }

    private Gtk.Widget build_field (string label_text, Gtk.Widget widget) {
        var box = new Gtk.Box (VERTICAL, 4) { hexpand = true };
        var label = new Gtk.Label (label_text) { halign = START, xalign = 0 };
        label.add_css_class ("ai-field-label");
        box.append (label);
        box.append (widget);
        return box;
    }

    private Gtk.Widget build_field_with_error (string label_text, Gtk.Widget widget, Gtk.Widget error_widget) {
        var box = new Gtk.Box (VERTICAL, 4) { hexpand = true };
        var label = new Gtk.Label (label_text) { halign = START, xalign = 0 };
        label.add_css_class ("ai-field-label");
        box.append (label);
        box.append (widget);
        box.append (error_widget);
        return box;
    }

    private Gtk.Widget wrap_text_view (Gtk.TextView text_view) {
        var scrolled_window = new Gtk.ScrolledWindow () {
            hexpand = true,
            min_content_height = 24,
            propagate_natural_height = true
        };
        scrolled_window.add_css_class ("ai-text-frame");
        scrolled_window.set_policy (Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC);
        scrolled_window.child = text_view;
        return scrolled_window;
    }

    private bool check_password () {
        if (pw_entry.text == "") {
            confirm_entry.text = "";
            confirm_entry.sensitive = false;

            pw_levelbar.value = 0;

            pw_entry.set_icon_from_icon_name (Gtk.EntryIconPosition.SECONDARY, null);
            pw_error_revealer.reveal_child = false;
        } else {
            confirm_entry.sensitive = true;

            var pwquality = new PasswordQuality.Settings ();
            void* error;
            var quality = pwquality.check (pw_entry.text, null, null, out error);

            if (quality >= 0) {
                pw_entry.set_icon_from_icon_name (Gtk.EntryIconPosition.SECONDARY, "process-completed-symbolic");
                pw_error_revealer.reveal_child = false;

                pw_levelbar.value = quality;

                if (quality <= 50) {
                    queue_announce (pw_entry, _("Acceptable password"));
                } else if (quality <= 75) {
                    queue_announce (pw_entry, _("Good password"));
                } else {
                    queue_announce (pw_entry, _("Great password"));
                }
            } else {
                pw_entry.set_icon_from_icon_name (Gtk.EntryIconPosition.SECONDARY, "dialog-warning-symbolic");

                pw_error_revealer.reveal_child = true;
                pw_error_revealer.label = ((PasswordQuality.Error) quality).to_string (error);

                pw_levelbar.value = 0;

                queue_announce (pw_entry, pw_error_revealer.label);
            }
            return true;
        }

        return false;
    }

    private bool confirm_password () {
        if (confirm_entry.text != "") {
            if (pw_entry.text != confirm_entry.text) {
                confirm_entry_revealer.label = _("Passwords do not match");
                confirm_entry_revealer.reveal_child = true;

                queue_announce (confirm_entry, confirm_entry_revealer.label);
            } else {
                confirm_entry_revealer.reveal_child = false;
                queue_announce (confirm_entry, _("Passwords match"));
                return true;
            }
        } else {
            confirm_entry_revealer.reveal_child = false;
        }

        return false;
    }

    private bool can_announce_accessibility () {
        unowned GLib.Application? application = GLib.Application.get_default ();
        if (application == null || !application.get_is_registered ()) {
            return false;
        }

        return application.get_dbus_connection () != null;
    }

    private void queue_announce (Gtk.Entry entry, string announcement) {
        /* announce() requires GTK ≥ 4.14 — skip on older runtimes to avoid crash */
        return;

        if (announce_timeout_id != 0) {
            Source.remove (announce_timeout_id);
            announce_timeout_id = 0;
        }

        announce_timeout_id = Timeout.add (500, () => {
            announce_timeout_id = 0;

            if (!can_announce_accessibility () || entry.get_root () == null) {
                return GLib.Source.REMOVE;
            }

            entry.announce (announcement, MEDIUM);
            return GLib.Source.REMOVE;
        });
    }

    private bool check_username () {
        string username_entry_text = username_text_view.buffer.text.strip ();
        bool username_is_valid = is_valid_username (username_entry_text);
        bool username_is_taken = is_taken_username (username_entry_text);

        if (username_entry_text == "") {
            username_error_revealer.reveal_child = false;
        } else if (username_is_valid && !username_is_taken) {
            username_error_revealer.reveal_child = false;
            return true;
        } else {
            if (username_is_taken) {
                username_error_revealer.label = _("The chosen username is already taken");
            } else if (!username_is_valid) {
                username_error_revealer.label = _("A username must only contain lowercase letters, numbers, hyphens, and underscores, without spaces");
            }

            username_error_revealer.reveal_child = true;
        }

        return false;
    }

    private bool check_hostname () {
        return Utils.gen_hostname (hostname_text_view.buffer.text.strip ()).length > 0;
    }

    private void update_finish_button () {
        if (username_valid && pw_valid && confirm_valid && hostname_valid) {
            finish_button.sensitive = true;
            ((Gtk.Window) get_root ()).default_widget = finish_button;
        } else {
            finish_button.sensitive = false;
        }
    }

    private void apply_settings () {
        finish_button.label = _("Creating Account…");
        finish_button.sensitive = false;
        content_area.sensitive = false;
        apply_settings_async.begin ((obj, res) => {
            unowned Installer.AccountView self = (Installer.AccountView)obj;
            self.apply_settings_async.end (res);
            self.content_area.sensitive = true;
            self.finish_button.label = _("Create Account");
        });
    }

    private async void apply_settings_async () {
        if (!yield set_hostname (hostname_text_view.buffer.text.strip ())) {
            return;
        }

        var created_user = yield create_new_user ();
        if (created_user == null) {
            return;
        }

        created_user.set_password (pw_entry.text, "");
        yield set_accounts_service_settings (created_user);
        yield set_locale (created_user);
        account_ready (created_user, username_text_view.buffer.text.strip (), realname_text_view.buffer.text.strip ());
    }

    private async Act.User? create_new_user () {
        Act.User? created_user = null;
        /* Root always has permission — skip Polkit which fails without agent */
        if (Posix.getuid () == 0 || (permission != null && permission.allowed)) {
            try {
                created_user = yield user_manager.create_user_async (username_text_view.buffer.text.strip (), realname_text_view.buffer.text.strip (), Act.UserAccountType.ADMINISTRATOR, null);
                return created_user;
            } catch (Error e) {
                if (created_user != null) {
                    try {
                        yield user_manager.delete_user_async (created_user, true, null);
                    } catch (Error e) {
                        critical ("Unable to clean up failed user: %s", e.message);
                    }
                }

                show_account_creation_error (
                    _("Creating an account for \u201c%s\u201d failed").printf (username_text_view.buffer.text.strip ()),
                    e.message
                );

                return null;
            }
        } else {
            show_account_creation_error (_("Couldn\u2019t get permission to create an account for \u201c%s\u201d").printf (username_text_view.buffer.text.strip ()));
            return null;
        }
    }

    const int MAX_TRIES = 10;
    public async bool set_hostname (string hostname) {
        try {
            /* Root always has permission — skip Polkit which fails without agent */
            if (Posix.getuid () == 0 || (permission != null && permission.allowed)) {
                var static_hostname = Utils.gen_hostname (hostname);
                yield hostname_iface.set_pretty_hostname (hostname, false);
                yield hostname_iface.set_static_hostname (static_hostname, false);
                Environ.set_variable (Environ.get (), "HOSTNAME", static_hostname, true);
            } else {
                show_hostname_setup_error (_("Couldn\u2019t get permission to name this device \u201c%s\u201d").printf (hostname));
                return false;
            }
        } catch (GLib.Error e) {
            show_hostname_setup_error (_("Unable to name this device \u201c%s\u201d").printf (hostname), e.message);
            return false;
        }

        return true;
    }

    private async void set_locale (Act.User? created_user) {
        string lang = Configuration.get_default ().lang;
        string? locale = null;
        bool success = yield LocaleHelper.language2locale (lang, out locale);

        if (!success || locale == null || locale == "") {
            warning ("Falling back to setting unconverted language as user's locale, may result in incorrect language");
            created_user.set_language (lang);
        } else {
            created_user.set_language (locale);
        }
    }

    private async void set_accounts_service_settings (Act.User? created_user) {
        AccountsService accounts_service = null;

        try {
            var act_service = yield GLib.Bus.get_proxy<FDO.Accounts> (GLib.BusType.SYSTEM,
                                                                      "org.freedesktop.Accounts",
                                                                      "/org/freedesktop/Accounts");
            var user_path = act_service.find_user_by_name (created_user.user_name);

            accounts_service = yield GLib.Bus.get_proxy (GLib.BusType.SYSTEM,
                                                        "org.freedesktop.Accounts",
                                                        user_path,
                                                        GLib.DBusProxyFlags.GET_INVALIDATED_PROPERTIES);
        } catch (Error e) {
            warning ("Unable to get AccountsService proxy, settings on new user may be incorrect: %s", e.message);
        }

        if (accounts_service != null) {
            var layouts = Configuration.get_default ().keyboard_layout.to_accountsservice_array ();
            if (Configuration.get_default ().keyboard_variant != null) {
                layouts = Configuration.get_default ().keyboard_variant.to_accountsservice_array ();
            }

            accounts_service.keyboard_layouts = layouts;
            accounts_service.left_handed = Configuration.get_default ().left_handed;
        }
    }

    private void show_hostname_setup_error (string primary_text, string? error_message = null) {
        var error_dialog = new Granite.MessageDialog.with_image_from_icon_name (
            primary_text,
            _("Initial Setup could not set your hostname."),
            "dialog-error",
            Gtk.ButtonsType.CLOSE
        ) {
            modal = true,
            transient_for = (Gtk.Window) get_root ()
        };

        if (error_message != null) {
            error_dialog.show_error_details (error_message);
        }

        error_dialog.present ();
        error_dialog.response.connect (error_dialog.destroy);
    }

    private void show_account_creation_error (string primary_text, string? error_message = null) {
        var error_dialog = new Granite.MessageDialog.with_image_from_icon_name (
            primary_text,
            _("Initial Setup could not create this account. Without it, you will not be able to log in and may need to reinstall the OS."),
            "system-users",
            Gtk.ButtonsType.CLOSE
        ) {
            badge_icon = new ThemedIcon ("dialog-error"),
            modal = true,
            transient_for = (Gtk.Window) get_root ()
        };

        if (error_message != null) {
            error_dialog.show_error_details (error_message);
        }

        error_dialog.present ();
        error_dialog.response.connect (error_dialog.destroy);
    }

    private bool is_taken_username (string username) {
        foreach (unowned Act.User user in user_manager.list_users ()) {
            if (user.get_user_name () == username) {
                return true;
            }
        }
        return false;
    }

    private bool is_valid_username (string username) {
        try {
            if (new Regex ("^[a-z]+[-a-z0-9_]*$").match (username)) {
                return true;
            }
            return false;
        } catch (Error e) {
            critical (e.message);
            return false;
        }
    }

    private string gen_username (string fullname) {
        string username = "";
        bool met_alpha = false;
        const char[] ALLOWED_MARKS = {
            '-',
            '_'
        };

        foreach (char c in fullname.to_ascii ().to_utf8 ()) {
            if (c.isalpha ()) {
                username += c.to_string ().down ();
                met_alpha = true;
            } else if ((c.isdigit () || c in ALLOWED_MARKS) && met_alpha) {
                username += c.to_string ();
            }
        }

        return username;
    }

    private class ErrorRevealer : Gtk.Box {
        public bool reveal_child { get; set; }
        public Gtk.Label label_widget { get; private set; }
        public string label { get; construct set; }

        public ErrorRevealer (string label) {
            Object (label: label);
        }

        construct {
            label_widget = new Gtk.Label (label) {
                halign = END,
                justify = RIGHT,
                max_width_chars = 55,
                use_markup = true,
                wrap = true,
                xalign = 1
            };
            label_widget.add_css_class (Granite.CssClass.SMALL);

            var revealer = new Gtk.Revealer () {
                child = label_widget,
                transition_type = CROSSFADE
            };

            append (revealer);

            bind_property ("reveal-child", revealer, "reveal-child");
            bind_property ("label", label_widget, "label");
        }
    }
}
