[CCode (cname = "gtk_style_context_add_provider_for_display")]
private extern void installer_add_provider_for_display (
    Gdk.Display display,
    Gtk.StyleProvider provider,
    uint priority
);

/*-
 * Copyright 2016-2022 elementary, Inc. (https://elementary.io)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Authored by: Corentin Noël <corentin@elementary.io>
 */

public class Installer.App : Gtk.Application {
    construct {
        application_id = "io.elementary.installer";
        flags = ApplicationFlags.FLAGS_NONE;
        Intl.setlocale (LocaleCategory.ALL, "");
    }

    public override void startup () {
        base.startup ();

        Granite.init ();
        register_bundled_fonts ();
        load_stylesheet ();
    }

    /**
     * Register bundled fonts (Doto, Space Grotesk, Space Mono) with fontconfig
     * so Pango can resolve them from CSS font-family declarations.
     *
     * GTK4 does NOT support @font-face — fonts must be known to fontconfig
     * before the CssProvider parses font-family names.
     *
     * Tries two paths:
     *   1. Installed: /usr/share/fonts/truetype/<app-id>/  (post meson install)
     *   2. Source:    ../data/fonts/  (development builds)
     */
    private void register_bundled_fonts () {
        /* meson installs fonts under meson.project_name() which is
         * "io.elementary.initial-setup", while application_id is
         * "io.elementary.installer".  Use the project name constant. */
        var installed_font_dir = Path.build_filename (
            "/usr", "share", "fonts", "truetype", "io.elementary.initial-setup"
        );
        var source_font_dir = Path.build_filename (
            Build.PKGDATADIR, "..", "..", "data", "fonts"
        );

        /* Also check relative to the source tree for development */
        string? source_tree_font_dir = null;
        var src_dir = Path.get_dirname (
            Path.get_dirname (GLib.Environment.get_current_dir ())
        );
        var candidate = Path.build_filename (src_dir, "data", "fonts");
        if (FileUtils.test (candidate, FileTest.IS_DIR)) {
            source_tree_font_dir = candidate;
        }

        unowned var fc_config = Fc.Config.get_current ();
        if (fc_config == null) {
            warning ("Unable to get fontconfig configuration");
            return;
        }

        bool registered = false;

        if (FileUtils.test (installed_font_dir, FileTest.IS_DIR)) {
            registered = fc_config.app_font_add_dir (installed_font_dir);
            if (registered) {
                message ("Registered bundled fonts from %s", installed_font_dir);
            }
        }

        if (!registered && FileUtils.test (source_font_dir, FileTest.IS_DIR)) {
            registered = fc_config.app_font_add_dir (source_font_dir);
            if (registered) {
                message ("Registered bundled fonts from %s (source fallback)", source_font_dir);
            }
        }

        if (!registered && source_tree_font_dir != null) {
            registered = fc_config.app_font_add_dir (source_tree_font_dir);
            if (registered) {
                message ("Registered bundled fonts from %s (source tree)", source_tree_font_dir);
            }
        }

        if (!registered) {
            warning (
                "Could not register bundled fonts. CSS font-family declarations " +
                "for Doto, Space Grotesk, and Space Mono will fall back to system fonts. " +
                "Searched: %s, %s",
                installed_font_dir, source_font_dir
            );
        }
    }

    private void load_stylesheet () {
        var display = Gdk.Display.get_default ();
        if (display == null) {
            return;
        }

        var provider = new Gtk.CssProvider ();
        var stylesheet_path = Path.build_filename (Build.PKGDATADIR, "styles", "nothing-installer.css");

        if (!FileUtils.test (stylesheet_path, FileTest.EXISTS)) {
            warning ("Unable to find installer stylesheet at %s", stylesheet_path);
            return;
        }

        provider.load_from_path (stylesheet_path);
        installer_add_provider_for_display (
            display,
            provider,
            Gtk.STYLE_PROVIDER_PRIORITY_USER
        );
    }

    public override void activate () {
        var window = new MainWindow () {
            default_height = 600,
            default_width = 850,
            deletable = false,
            icon_name = application_id,
            title = _("Create a User")
        };
        window.present ();
        add_window (window);
    }
}

public static int main (string[] args) {
    /* When running as root (initial-setup runs via sudo), many user-session
     * services crash because they belong to the unprivileged user:
     *   - AT-SPI accessibility bridge → segfault on session bus
     *   - IBus input method → "owner is not root!" → segfault on keystroke
     *   - dconf → "failed to commit changes" → segfault on GSettings write
     * Disable all of them before GTK initializes. */
    if (Posix.getuid () == 0) {
        Environment.set_variable ("GTK_A11Y", "none", true);
        Environment.set_variable ("NO_AT_BRIDGE", "1", true);
        Environment.set_variable ("GTK_IM_MODULE", "gtk-im-context-simple", true);
        Environment.set_variable ("GSETTINGS_BACKEND", "memory", true);
    }

    var application = new Installer.App ();
    return application.run (args);
}
