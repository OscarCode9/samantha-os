/*
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

public class Installer.ProvisionHelper : Object {
    public static int main (string[] args) {
        Intl.setlocale (LocaleCategory.ALL, "");

        if (args.length < 2 || args[1] != "provision") {
            stderr.printf ("usage: %s provision\n", args[0]);
            return 2;
        }

        try {
            string payload;
            size_t payload_length;

            if (!FileUtils.get_contents ("/dev/stdin", out payload, out payload_length)) {
                throw new FileError.FAILED ("unable to read provisioning payload");
            }

            var parser = new Json.Parser ();
            parser.load_from_data (payload, (ssize_t) payload_length);

            var root = parser.get_root ();
            if (root == null || root.get_node_type () != Json.NodeType.OBJECT) {
                throw new Installer.OpenClawBootstrapError.INVALID_RESPONSE ("provisioning payload must be a JSON object");
            }

            var request = root.get_object ();
            var profile_json = request.get_object_member ("profile");
            var profile = new Installer.OpenClawOnboardingProfile (
                profile_json.get_string_member ("assistant_name"),
                profile_json.get_string_member ("assistant_nature"),
                profile_json.get_string_member ("assistant_vibe"),
                profile_json.get_string_member ("preferred_user_name"),
                profile_json.get_string_member ("soul_directives"),
                profile_json.get_string_member ("user_context")
            );

            Installer.OpenClawBootstrap.provision_home_directory (
                request.get_string_member ("home_dir"),
                (int) request.get_int_member ("uid"),
                (int) request.get_int_member ("gid"),
                request.get_string_member ("user_name"),
                request.get_string_member ("real_name"),
                request.get_string_member ("github_token"),
                profile
            );

            return 0;
        } catch (Error e) {
            stderr.printf ("%s\n", e.message);
            return 1;
        }
    }
}