package mcp

import (
	"context"
	"fmt"
	"net"
	"net/http"
	"net/url"
	"os/exec"
	"runtime"
	"strings"
	"time"
)

// AuthFlowParams holds the parameters needed to run an interactive OAuth2
// authorization code + PKCE flow for an MCP server.
type AuthFlowParams struct {
	ServerName    string
	ClientID      string
	ClientSecret  string
	AuthEndpoint  string
	TokenEndpoint string
	Scopes        string
	TokenPath     string
}

// RunAuthFlow performs an interactive OAuth2 authorization code + PKCE flow:
// 1. Starts a local HTTP server on a random port to receive the callback.
// 2. Opens the browser to the authorization URL.
// 3. Waits for the authorization code.
// 4. Exchanges the code for a token.
// 5. Saves the token to TokenPath.
func RunAuthFlow(p AuthFlowParams) error {
	verifier, challenge, err := pkce()
	if err != nil {
		return fmt.Errorf("generate PKCE: %w", err)
	}

	// Start local callback server.
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		return fmt.Errorf("start callback server: %w", err)
	}
	defer listener.Close()

	port := listener.Addr().(*net.TCPAddr).Port
	redirectURI := fmt.Sprintf("http://127.0.0.1:%d/callback", port)

	codeCh := make(chan string, 1)
	errCh := make(chan error, 1)

	mux := http.NewServeMux()
	mux.HandleFunc("/callback", func(w http.ResponseWriter, r *http.Request) {
		code := r.URL.Query().Get("code")
		if code == "" {
			errMsg := r.URL.Query().Get("error_description")
			if errMsg == "" {
				errMsg = r.URL.Query().Get("error")
			}
			errCh <- fmt.Errorf("OAuth callback error: %s", errMsg)
			fmt.Fprint(w, "<html><body><h2>Authorization failed.</h2><p>"+errMsg+"</p></body></html>")
			return
		}
		codeCh <- code
		fmt.Fprint(w, "<html><body><h2>Authorization successful!</h2><p>You can close this window.</p></body></html>")
	})

	srv := &http.Server{Handler: mux}
	go srv.Serve(listener) //nolint:errcheck

	// Build the authorization URL.
	params := url.Values{}
	params.Set("response_type", "code")
	params.Set("client_id", p.ClientID)
	params.Set("redirect_uri", redirectURI)
	params.Set("scope", p.Scopes)
	params.Set("code_challenge", challenge)
	params.Set("code_challenge_method", "S256")
	params.Set("state", challenge[:8]) // simple CSRF token

	authURL := p.AuthEndpoint + "?" + params.Encode()

	fmt.Printf("Opening browser for MCP server %q authorization...\n", p.ServerName)
	fmt.Printf("If the browser does not open, visit:\n  %s\n\n", authURL)
	openBrowser(authURL)

	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Minute)
	defer cancel()

	var code string
	select {
	case code = <-codeCh:
	case err = <-errCh:
		return err
	case <-ctx.Done():
		return fmt.Errorf("timed out waiting for OAuth callback (2 min)")
	}

	tok, err := ExchangeCode(p.TokenEndpoint, p.ClientID, p.ClientSecret, code, verifier, redirectURI)
	if err != nil {
		return err
	}

	if err := SaveToken(p.TokenPath, tok); err != nil {
		return err
	}

	fmt.Printf("Token saved to %s\n", p.TokenPath)
	if !tok.ExpiresAt.IsZero() {
		fmt.Printf("Expires at: %s\n", tok.ExpiresAt.Format(time.RFC3339))
	}
	return nil
}

// openBrowser tries to open a URL in the default system browser.
func openBrowser(u string) {
	var cmd string
	var args []string

	switch runtime.GOOS {
	case "darwin":
		cmd = "open"
		args = []string{u}
	case "linux":
		// Try xdg-open, then common browsers.
		for _, bin := range []string{"xdg-open", "epiphany", "firefox", "chromium-browser"} {
			if _, err := exec.LookPath(bin); err == nil {
				cmd = bin
				args = []string{u}
				break
			}
		}
	case "windows":
		cmd = "cmd"
		// Replace & with ^& to avoid shell interpretation.
		args = []string{"/c", "start", strings.ReplaceAll(u, "&", "^&")}
	}

	if cmd == "" {
		return
	}
	exec.Command(cmd, args...).Start() //nolint:errcheck
}
