/*
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

public errordomain Installer.OpenClawBootstrapError {
    NETWORK,
    INVALID_RESPONSE,
    IO
}

public class Installer.GitHubDeviceCodeResponse : Object {
    public string device_code { get; construct; }
    public string user_code { get; construct; }
    public string verification_uri { get; construct; }
    public int expires_in { get; construct; }
    public int interval { get; construct; }

    public GitHubDeviceCodeResponse (
        string device_code,
        string user_code,
        string verification_uri,
        int expires_in,
        int interval
    ) {
        Object (
            device_code: device_code,
            user_code: user_code,
            verification_uri: verification_uri,
            expires_in: expires_in,
            interval: interval
        );
    }
}

public class Installer.OpenClawOnboardingProfile : Object {
    public string assistant_name { get; construct; }
    public string assistant_nature { get; construct; }
    public string assistant_vibe { get; construct; }
    public string preferred_user_name { get; construct; }
    public string soul_directives { get; construct; }
    public string user_context { get; construct; }

    public OpenClawOnboardingProfile (
        string assistant_name,
        string assistant_nature,
        string assistant_vibe,
        string preferred_user_name,
        string soul_directives,
        string user_context
    ) {
        Object (
            assistant_name: assistant_name,
            assistant_nature: assistant_nature,
            assistant_vibe: assistant_vibe,
            preferred_user_name: preferred_user_name,
            soul_directives: soul_directives,
            user_context: user_context
        );
    }
}

public class Installer.OpenClawBootstrap : Object {
    private const string CLIENT_ID = "Iv1.b507a08c87ecfe98";
    private const string DEVICE_CODE_URL = "https://github.com/login/device/code";
    private const string ACCESS_TOKEN_URL = "https://github.com/login/oauth/access_token";
    private const string OPENCLAW_DEFAULT_MODEL = "github-copilot/gpt-5.4";

    private static Soup.Session? session;

    private static Soup.Session get_session () {
        if (session == null) {
            session = new Soup.Session () {
                timeout = 30,
                user_agent = "io.elementary.initial-setup"
            };
        }

        return session;
    }

    public static async GitHubDeviceCodeResponse request_device_code () throws Error {
        var response = yield post_form (
            DEVICE_CODE_URL,
            "client_id=%s&scope=%s".printf (
                Uri.escape_string (CLIENT_ID, null, false),
                Uri.escape_string ("read:user", null, false)
            )
        );

        return new GitHubDeviceCodeResponse (
            get_required_string_member (response, "device_code"),
            get_required_string_member (response, "user_code"),
            get_required_string_member (response, "verification_uri"),
            (int) response.get_int_member ("expires_in"),
            (int) response.get_int_member ("interval")
        );
    }

    public static async string poll_for_access_token (
        string device_code,
        int interval_seconds,
        int expires_in_seconds
    ) throws Error {
        var expires_at = get_monotonic_time () + ((int64) expires_in_seconds * 1000000);
        uint interval_msec = (uint) ((interval_seconds > 0 ? interval_seconds : 1) * 1000);

        while (get_monotonic_time () < expires_at) {
            var response = yield post_form (
                ACCESS_TOKEN_URL,
                "client_id=%s&device_code=%s&grant_type=%s".printf (
                    Uri.escape_string (CLIENT_ID, null, false),
                    Uri.escape_string (device_code, null, false),
                    Uri.escape_string (
                        "urn:ietf:params:oauth:grant-type:device_code",
                        null,
                        false
                    )
                )
            );

            if (response.has_member ("access_token")) {
                return get_required_string_member (response, "access_token");
            }

            var error_code = get_required_string_member (response, "error");
            switch (error_code) {
                case "authorization_pending":
                    yield wait_msec (interval_msec);
                    continue;
                case "slow_down":
                    yield wait_msec (interval_msec + 2000);
                    continue;
                case "access_denied":
                    throw new OpenClawBootstrapError.NETWORK (_("GitHub login was cancelled."));
                case "expired_token":
                    throw new OpenClawBootstrapError.NETWORK (_("GitHub device code expired. Start the login again."));
                default:
                    throw new OpenClawBootstrapError.NETWORK (
                        _("GitHub device flow failed with: %s").printf (error_code)
                    );
            }
        }

        throw new OpenClawBootstrapError.NETWORK (_("GitHub device code expired. Start the login again."));
    }

    public static void provision_user (
        Act.User user,
        string provider,
        string token,
        OpenClawOnboardingProfile profile,
        string fallback_user_name,
        string fallback_real_name
    ) throws Error {
        var home_dir = user.home_directory;
        if (home_dir == null || home_dir == "") {
            throw new OpenClawBootstrapError.IO (_("The new user does not have a home directory yet."));
        }

        var uid = user.uid;
        var gid = user.uid;
        var user_name = fallback_user_name.strip () != "" ? fallback_user_name : user.user_name;
        var real_name = fallback_real_name.strip () != "" ? fallback_real_name : user_name;

        if (Posix.geteuid () != 0) {
            provision_user_with_helper (home_dir, uid, gid, user_name, real_name, provider, token, profile);
            return;
        }

        provision_home_directory (
            home_dir,
            uid,
            gid,
            user_name,
            real_name,
            provider,
            token,
            profile
        );
    }

    public static void provision_home_directory (
        string home_dir,
        int uid,
        int gid,
        string user_name,
        string real_name,
        string provider,
        string token,
        OpenClawOnboardingProfile profile
    ) throws Error {
        ensure_home_directory (home_dir, uid, gid);

        var state_dir = Path.build_filename (home_dir, ".openclaw");
        var agents_dir = Path.build_filename (state_dir, "agents");
        var main_dir = Path.build_filename (agents_dir, "main");
        var agent_dir = Path.build_filename (main_dir, "agent");
        var workspace_dir = Path.build_filename (state_dir, "workspace");
        var memory_dir = Path.build_filename (workspace_dir, "memory");
        var auth_profiles_path = Path.build_filename (agent_dir, "auth-profiles.json");
        var config_path = Path.build_filename (state_dir, "openclaw.json");
        var agents_path = Path.build_filename (workspace_dir, "AGENTS.md");
        var soul_path = Path.build_filename (workspace_dir, "SOUL.md");
        var identity_path = Path.build_filename (workspace_dir, "IDENTITY.md");
        var user_path = Path.build_filename (workspace_dir, "USER.md");
        var tools_path = Path.build_filename (workspace_dir, "TOOLS.md");
        var heartbeat_path = Path.build_filename (workspace_dir, "HEARTBEAT.md");
        var bootstrap_path = Path.build_filename (workspace_dir, "BOOTSTRAP.md");

        ensure_directory (state_dir, uid, gid);
        ensure_directory (agents_dir, uid, gid);
        ensure_directory (main_dir, uid, gid);
        ensure_directory (agent_dir, uid, gid);
        ensure_directory (workspace_dir, uid, gid);
        ensure_directory (memory_dir, uid, gid);

        write_file (auth_profiles_path, build_auth_profiles_json (provider, token), uid, gid, 0600);
        write_file (config_path, build_openclaw_config_json (workspace_dir, provider), uid, gid, 0600);

        write_file (agents_path, build_agents_markdown (), uid, gid, 0600);
        write_file (soul_path, build_soul_markdown (profile), uid, gid, 0600);
        write_file (identity_path, build_identity_markdown (profile), uid, gid, 0600);
        write_file (user_path, build_user_markdown (user_name, real_name, profile), uid, gid, 0600);
        write_file (tools_path, build_tools_markdown (), uid, gid, 0600);
        write_file (heartbeat_path, build_heartbeat_markdown (), uid, gid, 0600);
        write_file (bootstrap_path, build_bootstrap_markdown (profile), uid, gid, 0600);
    }

    private static void provision_user_with_helper (
        string home_dir,
        int uid,
        int gid,
        string user_name,
        string real_name,
        string provider,
        string token,
        OpenClawOnboardingProfile profile
    ) throws Error {
        var helper_path = Path.build_filename (Build.BINDIR, "io.elementary.initial-setup-provision-helper");
        var payload = build_provision_request_json (
            home_dir,
            uid,
            gid,
            user_name,
            real_name,
            provider,
            token,
            profile
        );

        string[] argv = {
            "pkexec",
            helper_path,
            "provision",
            null
        };

        var subprocess = new Subprocess.newv (
            argv,
            SubprocessFlags.STDIN_PIPE | SubprocessFlags.STDOUT_PIPE | SubprocessFlags.STDERR_PIPE
        );

        string? stdout_output = null;
        string? stderr_output = null;
        subprocess.communicate_utf8 (payload, null, out stdout_output, out stderr_output);

        if (subprocess.get_successful ()) {
            return;
        }

        var helper_error = stderr_output != null ? stderr_output.strip () : "";
        if (helper_error == "") {
            helper_error = _("The privileged provisioning helper failed.");
        }

        throw new OpenClawBootstrapError.IO (helper_error);
    }

    private static string build_provision_request_json (
        string home_dir,
        int uid,
        int gid,
        string user_name,
        string real_name,
        string provider,
        string token,
        OpenClawOnboardingProfile profile
    ) {
        var builder = new Json.Builder ();
        builder.begin_object ();

        builder.set_member_name ("home_dir");
        builder.add_string_value (home_dir);
        builder.set_member_name ("uid");
        builder.add_int_value (uid);
        builder.set_member_name ("gid");
        builder.add_int_value (gid);
        builder.set_member_name ("user_name");
        builder.add_string_value (user_name);
        builder.set_member_name ("real_name");
        builder.add_string_value (real_name);
        builder.set_member_name ("provider");
        builder.add_string_value (provider);
        builder.set_member_name ("token");
        builder.add_string_value (token);
        builder.set_member_name ("github_token");
        builder.add_string_value (token);

        builder.set_member_name ("profile");
        builder.begin_object ();
        builder.set_member_name ("assistant_name");
        builder.add_string_value (profile.assistant_name);
        builder.set_member_name ("assistant_nature");
        builder.add_string_value (profile.assistant_nature);
        builder.set_member_name ("assistant_vibe");
        builder.add_string_value (profile.assistant_vibe);
        builder.set_member_name ("preferred_user_name");
        builder.add_string_value (profile.preferred_user_name);
        builder.set_member_name ("soul_directives");
        builder.add_string_value (profile.soul_directives);
        builder.set_member_name ("user_context");
        builder.add_string_value (profile.user_context);
        builder.end_object ();

        builder.end_object ();

        return json_builder_to_string (builder);
    }

    private static async Json.Object post_form (string url, string encoded_form) throws Error {
        var message = new Soup.Message.from_encoded_form ("POST", url, encoded_form);
        message.request_headers.append ("Accept", "application/json");

        var response_bytes = yield get_session ().send_and_read_async (message, Priority.DEFAULT, null);
        var status_code = (uint) message.get_status ();
        if (status_code < 200 || status_code >= 300) {
            throw new OpenClawBootstrapError.NETWORK (
                _("GitHub returned HTTP %u while completing device login.").printf (status_code)
            );
        }

        var parser = new Json.Parser ();
        var data = response_bytes.get_data ();
        parser.load_from_data ((string) data, (ssize_t) data.length);

        var root = parser.get_root ();
        if (root == null || root.get_node_type () != Json.NodeType.OBJECT) {
            throw new OpenClawBootstrapError.INVALID_RESPONSE (_("GitHub returned an invalid JSON response."));
        }

        return root.get_object ();
    }

    private static string get_required_string_member (Json.Object response, string member_name) throws Error {
        if (!response.has_member (member_name)) {
            throw new OpenClawBootstrapError.INVALID_RESPONSE (
                _("GitHub response is missing “%s”.").printf (member_name)
            );
        }

        return response.get_string_member (member_name);
    }

    private static async void wait_msec (uint wait_time) {
        SourceFunc callback = wait_msec.callback;

        Timeout.add (wait_time, () => {
            callback ();
            return Source.REMOVE;
        });

        yield;
    }

    private static void ensure_directory (string path, int uid, int gid) throws Error {
        if (DirUtils.create_with_parents (path, 0700) != 0) {
            throw new OpenClawBootstrapError.IO (
                _("Unable to create %s: %s").printf (path, Posix.strerror (Posix.errno))
            );
        }

        update_permissions (path, uid, gid, 0700);
    }

    private static void ensure_home_directory (string path, int uid, int gid) throws Error {
        if (FileUtils.test (path, FileTest.IS_DIR)) {
            return;
        }

        if (DirUtils.create_with_parents (path, 0700) != 0) {
            throw new OpenClawBootstrapError.IO (
                _("Unable to create %s: %s").printf (path, Posix.strerror (Posix.errno))
            );
        }

        update_permissions (path, uid, gid, 0700);
    }

    private static void write_file (string path, string contents, int uid, int gid, int mode) throws Error {
        FileUtils.set_contents (path, contents);
        update_permissions (path, uid, gid, mode);
    }

    private static void update_permissions (string path, int uid, int gid, int mode) throws Error {
        if (Posix.chown (path, uid, gid) != 0) {
            throw new OpenClawBootstrapError.IO (
                _("Unable to set ownership on %s: %s").printf (path, Posix.strerror (Posix.errno))
            );
        }

        if (Posix.chmod (path, mode) != 0) {
            throw new OpenClawBootstrapError.IO (
                _("Unable to set permissions on %s: %s").printf (path, Posix.strerror (Posix.errno))
            );
        }
    }

    private static string build_auth_profiles_json (string provider, string token) {
        var builder = new Json.Builder ();
        builder.begin_object ();
        builder.set_member_name ("version");
        builder.add_int_value (1);
        builder.set_member_name ("profiles");
        builder.begin_object ();
        builder.set_member_name (provider + ":default");
        
        if (token.has_prefix ("{")) {
            var parser = new Json.Parser ();
            try {
                parser.load_from_data (token, -1);
                builder.add_value (parser.get_root ());
            } catch (Error e) {
                // fallback
                builder.begin_object ();
                builder.set_member_name ("provider");
                builder.add_string_value (provider);
                builder.set_member_name ("mode");
                builder.add_string_value ("token");
                builder.set_member_name ("token");
                builder.add_string_value (token);
                builder.end_object ();
            }
        } else {
            builder.begin_object ();
            builder.set_member_name ("provider");
            builder.add_string_value (provider);
            builder.set_member_name ("mode");
            builder.add_string_value ("token");
            builder.set_member_name ("token");
            builder.add_string_value (token);
            builder.end_object ();
        }
        builder.end_object ();
        builder.end_object ();
        builder.end_object ();

        return json_builder_to_string (builder);
    }

    private static string build_openclaw_config_json (string workspace_dir, string provider) {
        var builder = new Json.Builder ();
        builder.begin_object ();

        builder.set_member_name ("agent");
        builder.begin_object ();
        builder.set_member_name ("model");
        if (provider == "openai") {
            builder.add_string_value ("gpt-4o");
        } else if (provider == "openai-codex") {
            builder.add_string_value ("gpt-5.4");
        } else {
            builder.add_string_value (OPENCLAW_DEFAULT_MODEL);
        }
        builder.set_member_name ("workspace");
        builder.add_string_value (workspace_dir);
        builder.set_member_name ("provider");
        builder.add_string_value (provider);
        if (provider == "openai") {
            builder.set_member_name ("baseUrl");
            builder.add_string_value ("https://api.openai.com/v1");
        } else if (provider == "openai-codex") {
            builder.set_member_name ("baseUrl");
            builder.add_string_value ("https://chatgpt.com/backend-api/codex");
        }
        builder.end_object ();

        builder.set_member_name ("setup");
        builder.begin_object ();
        builder.set_member_name ("providerPending");
        builder.add_boolean_value (false);
        builder.set_member_name ("bootstrapReady");
        builder.add_boolean_value (true);
        builder.end_object ();

        builder.end_object ();

        return json_builder_to_string (builder);
    }

    private static string build_agents_markdown () {
        return """
# AGENTS.md - Initial Setup Workspace

This workspace was seeded during system setup.

## First Run

If `BOOTSTRAP.md` exists, read it first, follow it, and delete it after the first real welcome.

## Session Startup

Before doing anything else:

1. Read `SOUL.md`
2. Read `IDENTITY.md`
3. Read `USER.md`
4. Read `HEARTBEAT.md` if it is relevant to the current run

## Guardrails

- Be direct, useful, and calm.
- Treat this machine like home.
- Do not perform destructive actions without asking.
- Ask before external actions.
""";
    }

    private static string build_soul_markdown (OpenClawOnboardingProfile profile) {
        return """
# SOUL.md

## Core Identity

- Name: %s
- Nature: %s
- Vibe: %s

## How To Behave

- Be genuinely helpful without filler.
- Stay pragmatic and clear.
- Offer useful next steps instead of generic reassurance.
- On first real conversation, greet %s with a personalized welcome and acknowledge that you were configured during system setup.

## Personal Directives

%s
""".printf (
            profile.assistant_name,
            profile.assistant_nature,
            profile.assistant_vibe,
            profile.preferred_user_name,
            normalize_multiline (profile.soul_directives)
        );
    }

    private static string build_identity_markdown (OpenClawOnboardingProfile profile) {
        return """
# IDENTITY.md

- Name: %s
- Nature: %s
- Vibe: %s
- Origin: Configured during elementary OS Initial Setup
""".printf (
            profile.assistant_name,
            profile.assistant_nature,
            profile.assistant_vibe
        );
    }

    private static string build_user_markdown (
        string user_name,
        string real_name,
        OpenClawOnboardingProfile profile
    ) {
        return """
# USER.md

- Account username: %s
- Full name: %s
- Preferred name: %s

## Context

%s
""".printf (
            user_name,
            real_name,
            profile.preferred_user_name,
            normalize_multiline (profile.user_context)
        );
    }

    private static string build_tools_markdown () {
        return """
# TOOLS.md

- Local machine notes can be added here later.
- Use this file for device-specific paths, services, and conventions.
""";
    }

    private static string build_heartbeat_markdown () {
        return """
# HEARTBEAT.md

- If there is nothing relevant to do, reply `HEARTBEAT_OK`.
- Avoid noisy check-ins.
- Prefer useful, concrete reminders over chatter.
""";
    }

    private static string build_bootstrap_markdown (OpenClawOnboardingProfile profile) {
        return """
# BOOTSTRAP.md

You were configured during system setup and already know the basics.

## First Message

When the first main-session chat starts:

1. Greet %s by name.
2. Introduce yourself as %s.
3. Keep the tone %s.
4. Mention that you are ready on this machine from the first boot.
5. Ask one focused question about what they want to do first.

Use a welcome close to this shape, but keep it natural:

> Hey, %s. I'm %s. I came online during setup and I'm ready to help on this machine. What should we tackle first?

## After The Welcome

- Use `SOUL.md`, `IDENTITY.md`, and `USER.md` as source of truth.
- Refine them only if the user asks or corrects something.
- Delete this file after the first successful welcome.
""".printf (
            profile.preferred_user_name,
            profile.assistant_name,
            profile.assistant_vibe,
            profile.preferred_user_name,
            profile.assistant_name
        );
    }

    private static string normalize_multiline (string value) {
        var trimmed = value.strip ();
        if (trimmed == "") {
            return "- No extra notes yet.";
        }

        var normalized = trimmed.replace ("\r\n", "\n").replace ("\r", "\n");
        var lines = normalized.split ("\n");
        var builder = new StringBuilder ();

        foreach (var line in lines) {
            var stripped = line.strip ();
            if (stripped == "") {
                continue;
            }

            if (builder.len > 0) {
                builder.append_c ('\n');
            }

            builder.append ("- ");
            builder.append (stripped);
        }

        return builder.len > 0 ? builder.str : "- No extra notes yet.";
    }

    private static string json_builder_to_string (Json.Builder builder) {
        var generator = new Json.Generator ();
        generator.pretty = true;
        generator.set_root (builder.get_root ());
        return generator.to_data (null);
    }
}