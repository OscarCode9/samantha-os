/*
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * AIConnectView -- chat-based AI onboarding
 *
 * Flow:
 *   INTRO  (DNA animation)
 *   -> PRESENTATION  ("Semantha OS." cinematic)
 *   -> CONNECT  (GitHub device-code OAuth)
 *   -> CHAT  (agent drives the conversation via gateway tool calls)
 *   -> DONE  ("Ready." screen)
 */

public class Installer.AIConnectView : AbstractInstallerView {

    private enum Step {
        INTRO,
        PRESENTATION,
        CONNECT,
        CHAT,
        DONE
    }
    private Step step = Step.INTRO;

    /* -- DNA intro animation state -- */
    private Gtk.DrawingArea dna_canvas;
    private int    anim_frame = 0;
    private double anim_phase = 0.0;
    private uint   tick_id = 0;

    /* -- Auth -- */
    private Act.User created_user;
    private string   created_user_name = "";
    private string   created_user_real_name = "";
    private string   github_token = "";
    private string   verification_uri = "";

    /* -- Onboarding profile (built by AI tool calls) -- */
    private string profile_assistant_name = "Samantha";
    private string profile_user_name      = "";
    private string profile_personality    = "warm, direct, and helpful";
    private string profile_role           = "A local AI teammate for this computer";

    /* -- Chat UI -- */
    private Gtk.Box            chat_messages;
    private Gtk.ScrolledWindow outer_scroller;
    private Gtk.Entry          chat_entry;
    private Gtk.Button         send_button;
    private Gtk.Box            typing_box;
    private Gtk.Box            chat_box;

    /* -- Message history (pre-serialised JSON objects) -- */
    private Gee.ArrayList<string> chat_message_jsons;

    /* -- Unique session ID for this onboarding run (keeps history isolated from bootstrap) -- */
    private string onboarding_session_id = "";

    /* -- HTTP client -- */
    private Soup.Session http_session;

    /* -- Shared widgets -- */
    private Gtk.Image   hero_icon;
    private Gtk.Box     hero_box;
    private Gtk.Label   title_label;
    private Gtk.Label   subtitle_label;
    private Gtk.Box     state_indicator;
    private Gtk.Label   state_label;
    private Gtk.Box     device_code_box;
    private Gtk.Label   code_label;
    private Gtk.Label   status_label;
    private Gtk.Spinner spinner;
    private Gtk.Label   step_counter;
    private Gtk.Box     divider_line;
    private Gtk.Button  start_button;
    private Gtk.Button  connect_button;
    private Gtk.Button  finish_button;
    private Gtk.Button  chat_continue_button;

    /* -- Provider configuration -- */
    private string selected_provider = "github-copilot";
    private string chatgpt_profile_json = "";

    /* -- Provider selection widgets -- */
    private Gtk.Box provider_select_box;
    private Gtk.CheckButton github_radio;
    private Gtk.CheckButton chatgpt_radio;
    private Gtk.Box chatgpt_input_box;
    private Gtk.Button chatgpt_login_button;
    private Gtk.Entry chatgpt_url_entry;

    /* -- System prompt -- */
    private const string SYSTEM_PROMPT =
        "You are an AI assistant being set up on a new elementary OS computer called Samantha OS. " +
        "Your job: have a short, warm conversation to learn about the user. Be friendly and concise. " +
        "Max 2 sentences per message. No markdown, no bullet lists — just natural chat.\n\n" +
        "Step order:\n" +
        "1. Introduce yourself with a name you choose (default: Samantha) and call set_assistant_name immediately. Ask what the user would like to be called.\n" +
        "2. When they tell you their name, call set_user_name immediately. Acknowledge it and ask which personality they prefer: playful, professional, or direct.\n" +
        "3. When they choose a personality, call set_personality immediately. Confirm it and ask what your main role should be: productivity, coding assistant, creative partner, or general help.\n" +
        "4. When they answer, call set_role immediately. Give a warm one-sentence closing. Then call complete_onboarding.\n\n" +
        "IMPORTANT: Call the tools silently as you go — do not mention them or explain them to the user. " +
        "Keep it to 4 exchanges total. Be natural and warm.";

    /* -- Tool definitions (static JSON, embedded verbatim) -- */
    private const string ONBOARDING_TOOLS_JSON = """[
  {"type":"function","function":{"name":"set_assistant_name","description":"Set the name of this AI assistant.","parameters":{"type":"object","properties":{"name":{"type":"string"}},"required":["name"]}}},
  {"type":"function","function":{"name":"set_user_name","description":"Set the preferred name of the user.","parameters":{"type":"object","properties":{"name":{"type":"string"}},"required":["name"]}}},
  {"type":"function","function":{"name":"set_personality","description":"Set the assistant personality vibe.","parameters":{"type":"object","properties":{"vibe":{"type":"string"}},"required":["vibe"]}}},
  {"type":"function","function":{"name":"set_role","description":"Set the assistant main role or purpose.","parameters":{"type":"object","properties":{"role":{"type":"string"}},"required":["role"]}}},
  {"type":"function","function":{"name":"complete_onboarding","description":"Call when all profile info has been collected and onboarding is complete.","parameters":{"type":"object","properties":{}}}}
]""";

    /* ------------------------------------------------------------------ */
    /*  Constructor                                                         */
    /* ------------------------------------------------------------------ */

    public AIConnectView (Act.User created_user, string? created_user_name, string? created_user_real_name) {
        Object ();
        this.created_user           = created_user;
        this.created_user_name      = sanitize_user_text (created_user_name);
        this.created_user_real_name = sanitize_user_text (created_user_real_name);
        this.profile_user_name      = get_created_user_display_name ();

        http_session = new Soup.Session () {
            timeout = 30
        };

        build_ui ();
        update_step (Step.INTRO);
    }

    /* ------------------------------------------------------------------ */
    /*  build_ui                                                            */
    /* ------------------------------------------------------------------ */

    private void build_ui () {
        title = _("Connect AI");

        split_box.homogeneous = false;
        split_box.orientation = VERTICAL;
        split_box.spacing = 0;

        title_area.visible = false;
        action_area.halign = CENTER;
        action_area.homogeneous = false;
        action_area.spacing = 16;

        /* Hero area */
        hero_icon = new Gtk.Image.from_icon_name ("preferences-system-network") {
            pixel_size = 36
        };
        hero_icon.add_css_class ("ai-hero-icon");

        title_label = new Gtk.Label (_("Welcome to Samantha OS")) {
            halign = CENTER,
            justify = CENTER
        };
        title_label.add_css_class ("ai-hero-title");

        subtitle_label = new Gtk.Label (_("Connect with GitHub to bring your AI to life.")) {
            halign = CENTER,
            justify = CENTER,
            max_width_chars = 52,
            wrap = true
        };
        subtitle_label.add_css_class ("ai-hero-subtitle");

        var state_dot = new Gtk.Box (HORIZONTAL, 0) {
            width_request = 8,
            height_request = 8,
            valign = CENTER
        };
        state_dot.add_css_class ("ai-state-dot");
        state_dot.add_css_class ("ai-state-waiting");

        state_label = new Gtk.Label (_("Waiting to connect")) {
            valign = CENTER
        };
        state_label.add_css_class ("ai-state-label");

        state_indicator = new Gtk.Box (HORIZONTAL, 8) {
            halign = CENTER,
            margin_top = 4
        };
        state_indicator.append (state_dot);
        state_indicator.append (state_label);

        hero_box = new Gtk.Box (VERTICAL, 8) {
            halign = CENTER,
            margin_bottom = 20
        };
        hero_box.add_css_class ("ai-hero-box");
        hero_box.append (hero_icon);
        hero_box.append (title_label);
        hero_box.append (subtitle_label);
        hero_box.append (state_indicator);

        /* Device code card */
        spinner = new Gtk.Spinner () {
            halign = CENTER,
            visible = false
        };

        code_label = new Gtk.Label ("") {
            halign = CENTER,
            selectable = true
        };
        code_label.add_css_class ("ai-code");

        var open_browser_button = new Gtk.Button.with_label (_("Open Browser")) {
            halign = CENTER
        };
        open_browser_button.add_css_class ("ai-link-button");
        open_browser_button.clicked.connect (launch_browser);

        status_label = new Gtk.Label ("") {
            halign = CENTER,
            justify = CENTER,
            max_width_chars = 48,
            wrap = true,
            visible = false
        };
        status_label.add_css_class ("ai-status");

        var url_hint_label = new Gtk.Label ("github.com/login/device") {
            halign = CENTER,
            selectable = true
        };
        url_hint_label.add_css_class ("ai-url-hint");

        device_code_box = new Gtk.Box (VERTICAL, 12) {
            halign = CENTER,
            margin_top = 16,
            visible = false
        };
        device_code_box.add_css_class ("ai-code-card");
        device_code_box.append (new Gtk.Label (_("Enter this code on GitHub")) {
            halign = CENTER
        });
        device_code_box.append (code_label);
        device_code_box.append (url_hint_label);
        device_code_box.append (open_browser_button);

        /* DNA canvas */
        dna_canvas = new Gtk.DrawingArea () {
            halign = CENTER,
            valign = CENTER,
            hexpand = true,
            vexpand = true,
            content_width = 520,
            content_height = 240
        };
        dna_canvas.add_css_class ("ai-dna-canvas");
        dna_canvas.set_draw_func (draw_dna);

        /* Step counter + divider */
        step_counter = new Gtk.Label ("") {
            halign = CENTER,
            margin_bottom = 8,
            visible = false
        };
        step_counter.add_css_class ("ai-step-counter");

        divider_line = new Gtk.Box (HORIZONTAL, 0) {
            hexpand = true,
            height_request = 1,
            visible = false
        };
        divider_line.add_css_class ("ai-divider");

        /* Chat UI — plain Box avoids Adwaita ScrolledWindow/Viewport white bg */
        chat_messages = new Gtk.Box (VERTICAL, 0) {
            hexpand = true
        };
        chat_messages.add_css_class ("ai-chat-messages");

        var dot1 = new Gtk.Label ("\u2022");
        var dot2 = new Gtk.Label ("\u2022");
        var dot3 = new Gtk.Label ("\u2022");
        dot1.add_css_class ("ai-typing-dot");
        dot2.add_css_class ("ai-typing-dot");
        dot3.add_css_class ("ai-typing-dot");

        typing_box = new Gtk.Box (HORIZONTAL, 4) {
            halign = START,
            margin_start = 12,
            margin_bottom = 4,
            visible = false
        };
        typing_box.add_css_class ("ai-typing-box");
        typing_box.append (dot1);
        typing_box.append (dot2);
        typing_box.append (dot3);

        chat_entry = new Gtk.Entry () {
            hexpand = true,
            placeholder_text = _("Type your response\u2026"),
            sensitive = false
        };
        chat_entry.add_css_class ("ai-chat-input");
        chat_entry.activate.connect (on_send_message);

        send_button = new Gtk.Button.with_label ("\u2191") {
            valign = CENTER,
            sensitive = false
        };
        send_button.add_css_class ("ai-send-button");
        send_button.clicked.connect (on_send_message);

        var input_row = new Gtk.Box (HORIZONTAL, 8) {
            hexpand = true,
            margin_top = 8,
            margin_start = 4,
            margin_end = 4,
            margin_bottom = 4
        };
        input_row.append (chat_entry);
        input_row.append (send_button);

        chat_box = new Gtk.Box (VERTICAL, 0) {
            hexpand = true,
            vexpand = true,
            width_request = 520,
            visible = false
        };
        chat_box.add_css_class ("ai-chat-box");
        chat_box.append (chat_messages);
        chat_box.append (typing_box);
        chat_box.append (input_row);

        /* Presentation button */
        start_button = new Gtk.Button.with_label (_("Comenzar")) {
            halign = CENTER,
            visible = false
        };
        start_button.add_css_class ("ai-presentation-btn");
        start_button.clicked.connect (() => update_step (Step.CONNECT));

        /* Provider Selection Box */
        github_radio = new Gtk.CheckButton.with_label (_("GitHub Copilot"));
        github_radio.active = true;
        github_radio.toggled.connect (on_provider_toggled);

        chatgpt_radio = new Gtk.CheckButton.with_label (_("ChatGPT Subscription"));
        chatgpt_radio.group = github_radio;
        chatgpt_radio.toggled.connect (on_provider_toggled);

        var radio_box = new Gtk.Box (HORIZONTAL, 16) {
            halign = CENTER,
            margin_bottom = 12
        };
        radio_box.append (github_radio);
        radio_box.append (chatgpt_radio);

        chatgpt_url_entry = new Gtk.Entry () {
            placeholder_text = _("Paste redirect URL (http://localhost:1455/...)"),
            width_request = 350,
            halign = CENTER,
            visible = false
        };
        chatgpt_url_entry.changed.connect (on_chatgpt_url_changed);

        chatgpt_login_button = new Gtk.Button.with_label (_("Connect to ChatGPT")) {
            halign = CENTER
        };
        chatgpt_login_button.clicked.connect (on_chatgpt_login_clicked);

        chatgpt_input_box = new Gtk.Box (VERTICAL, 8) {
            halign = CENTER,
            visible = false,
            margin_top = 8
        };
        chatgpt_input_box.append (chatgpt_login_button);
        chatgpt_input_box.append (chatgpt_url_entry);

        provider_select_box = new Gtk.Box (VERTICAL, 8) {
            halign = CENTER,
            margin_top = 16,
            visible = false
        };
        provider_select_box.append (radio_box);
        provider_select_box.append (chatgpt_input_box);

        /* Center layout */
        var center_box = new Gtk.Box (VERTICAL, 0) {
            halign = CENTER,
            valign = CENTER,
            hexpand = true,
            vexpand = true,
            margin_start = 56,
            margin_end = 56,
            margin_top = 36,
            margin_bottom = 12
        };
        center_box.append (dna_canvas);
        center_box.append (step_counter);
        center_box.append (hero_box);
        center_box.append (divider_line);
        center_box.append (provider_select_box);
        center_box.append (device_code_box);
        center_box.append (chat_box);
        center_box.append (spinner);
        center_box.append (status_label);
        center_box.append (start_button);

        outer_scroller = new Gtk.ScrolledWindow () {
            hexpand = true,
            vexpand = true,
            propagate_natural_width = true
        };
        outer_scroller.add_css_class ("ai-main-scroller");
        outer_scroller.set_policy (Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC);
        outer_scroller.child = center_box;

        content_area.hexpand = true;
        content_area.vexpand = true;
        content_area.append (outer_scroller);

        /* Action buttons */
        finish_button = new Gtk.Button.with_label (_("Skip"));
        finish_button.add_css_class ("ai-secondary-btn");
        finish_button.clicked.connect (() => Application.get_default ().quit ());

        chat_continue_button = new Gtk.Button.with_label (_("Continue")) {
            visible = false,
            receives_default = true
        };
        chat_continue_button.add_css_class ("ai-primary-btn");
        chat_continue_button.clicked.connect (() => finish_onboarding.begin ());

        connect_button = new Gtk.Button.with_label (_("Connect with GitHub")) {
            receives_default = true,
            visible = false
        };
        connect_button.add_css_class ("ai-primary-btn");
        connect_button.clicked.connect (() => on_connect_clicked.begin ());

        action_area.append (finish_button);
        action_area.append (chat_continue_button);
        action_area.append (connect_button);
    }

    /* ------------------------------------------------------------------ */
    /*  Step transitions                                                    */
    /* ------------------------------------------------------------------ */

    private void update_step (Step new_step) {
        step = new_step;

        if (tick_id != 0) {
            dna_canvas.remove_tick_callback (tick_id);
            tick_id = 0;
        }

        /* Hide everything */
        dna_canvas.visible      = false;
        hero_box.visible        = false;
        device_code_box.visible = false;
        provider_select_box.visible = false;
        chat_box.visible        = false;
        spinner.visible         = false;
        status_label.visible    = false;
        start_button.visible    = false;
        step_counter.visible    = false;
        divider_line.visible    = false;
        finish_button.visible   = false;
        chat_continue_button.visible = false;
        connect_button.visible  = false;

        switch (step) {
            case Step.INTRO:
                split_box.add_css_class ("ai-presentation");
                dna_canvas.visible = true;
                anim_frame = 0;
                anim_phase = 0.0;
                tick_id = dna_canvas.add_tick_callback (on_anim_tick);
                break;

            case Step.PRESENTATION:
                split_box.add_css_class ("ai-presentation");
                hero_icon.visible = false;
                title_label.label = "Semantha OS.";
                title_label.remove_css_class ("ai-hero-title");
                title_label.add_css_class ("ai-presentation-title");
                subtitle_label.label = _("The first AI-native operating system.");
                subtitle_label.remove_css_class ("ai-hero-subtitle");
                subtitle_label.add_css_class ("ai-presentation-subtitle");
                state_indicator.visible = false;
                hero_box.visible = true;
                start_button.visible = true;
                break;

            case Step.CONNECT:
                split_box.remove_css_class ("ai-presentation");
                step_counter.label = "01 / 02";
                step_counter.visible = true;
                divider_line.visible = true;
                hero_icon.visible = false;
                title_label.label = _("Authorize.");
                title_label.remove_css_class ("ai-presentation-title");
                title_label.add_css_class ("ai-hero-title");
                subtitle_label.label = _("Choose your AI provider and activate Semantha.");
                subtitle_label.remove_css_class ("ai-presentation-subtitle");
                subtitle_label.add_css_class ("ai-hero-subtitle");
                state_indicator.visible = true;
                hero_box.visible = true;
                finish_button.visible = true;
                connect_button.visible = true;
                provider_select_box.visible = true;
                on_provider_toggled ();
                break;

            case Step.CHAT:
                split_box.remove_css_class ("ai-presentation");
                step_counter.label = "02 / 02";
                step_counter.visible = true;
                divider_line.visible = true;
                chat_box.visible = true;
                finish_button.visible = true;
                onboarding_session_id = "onboarding-%lld".printf (GLib.get_real_time () / 1000000);
                start_onboarding_chat.begin ();
                break;

            case Step.DONE:
                split_box.remove_css_class ("ai-presentation");
                hero_icon.icon_name = "process-completed";
                hero_icon.add_css_class ("ai-hero-success");
                hero_icon.visible = true;
                title_label.label = _("Ready.");
                title_label.remove_css_class ("ai-presentation-title");
                title_label.add_css_class ("ai-hero-title");
                subtitle_label.label = "I\u2019m %s. Let\u2019s get started.".printf (profile_assistant_name);
                subtitle_label.remove_css_class ("ai-presentation-subtitle");
                subtitle_label.add_css_class ("ai-hero-subtitle");
                state_indicator.visible = false;
                hero_box.visible = true;
                finish_button.visible = true;
                finish_button.label = _("Continue");
                finish_button.remove_css_class ("ai-secondary-btn");
                finish_button.add_css_class ("ai-primary-btn");
                break;
        }
    }

    /* ------------------------------------------------------------------ */
    /*  GitHub OAuth flow                                                   */
    /* ------------------------------------------------------------------ */

    private async void start_connect () {
        connect_button.sensitive = false;
        spinner.visible = true;
        spinner.start ();
        status_label.label = _("Contacting GitHub\u2026");
        status_label.visible = true;
        update_state (_("Connecting\u2026"), "ai-state-progress");

        try {
            var device = yield OpenClawBootstrap.request_device_code ();
            verification_uri = device.verification_uri;
            code_label.label = device.user_code;
            device_code_box.visible = true;
            launch_browser ();

            status_label.label = _("Approve the request in your browser, then come back.");
            update_state (_("Waiting for approval\u2026"), "ai-state-progress");

            github_token = yield OpenClawBootstrap.poll_for_access_token (
                device.device_code,
                device.interval,
                device.expires_in
            );

            spinner.stop ();
            spinner.visible = false;
            status_label.visible = false;
            device_code_box.visible = false;
            update_state (_("Connected"), "ai-state-success");
            update_step (Step.CHAT);

        } catch (Error e) {
            spinner.stop ();
            spinner.visible = false;
            connect_button.sensitive = true;
            status_label.label = _("Could not connect. Try again or skip.");
            status_label.visible = true;
            update_state (_("Not connected"), "ai-state-error");
            show_connect_error (_("Unable to connect"), e.message);
        }
    }

    /* ------------------------------------------------------------------ */
    /*  Chat onboarding                                                     */
    /* ------------------------------------------------------------------ */

    private async void start_onboarding_chat () {
        /* Clear any previous chat messages */
        var child = chat_messages.get_first_child ();
        while (child != null) {
            var next = child.get_next_sibling ();
            chat_messages.remove (child);
            child = next;
        }

        chat_message_jsons = new Gee.ArrayList<string> ();
        push_message_json ("system", SYSTEM_PROMPT);

        yield ai_turn ();
    }

    /* -- Message-history helpers -- */

    private void push_message_json (string role, string content) {
        string ec = escape_json_string (content);
        chat_message_jsons.add ("{\"role\":\"" + role + "\",\"content\":\"" + ec + "\"}");
    }


    private static string escape_json_string (string s) {
        return s
            .replace ("\\", "\\\\")
            .replace ("\"", "\\\"")
            .replace ("\n", "\\n")
            .replace ("\r", "\\r")
            .replace ("\t", "\\t");
    }

    /* -- Main AI conversation loop -- */

    private async void ai_turn () {
        typing_box.visible = true;
        chat_entry.sensitive = false;
        send_button.sensitive = false;
        scroll_to_bottom ();

        try {
            /* Tool-call loop: call gateway → if tool_calls, execute and loop.
               Breaks on finish_reason "stop" or after complete_onboarding. */
            while (true) {
                var response = yield call_gateway ();
                typing_box.visible = false;

                if (response == null) {
                    append_error_bubble (_("No response from gateway."));
                    break;
                }

                var choices_node = response.get_member ("choices");
                if (choices_node == null || choices_node.get_node_type () != Json.NodeType.ARRAY) {
                    append_error_bubble (_("Unexpected response from gateway."));
                    break;
                }

                var choices = choices_node.get_array ();
                if (choices.get_length () == 0) break;

                var choice = choices.get_object_element (0);
                if (choice == null) break;

                unowned string? finish_reason = choice.get_string_member_with_default ("finish_reason", "stop");
                var message = choice.get_object_member ("message");
                if (message == null) break;

                /* Append assistant message to history (preserving tool_calls) */
                chat_message_jsons.add (serialize_assistant_message (message));

                /* Pre-scan tool calls to check if onboarding completes in this turn */
                bool onboarding_complete = false;
                var tool_calls_node = message.get_member ("tool_calls");
                if (tool_calls_node != null && tool_calls_node.get_node_type () == Json.NodeType.ARRAY) {
                    var tool_calls = tool_calls_node.get_array ();
                    for (uint i = 0; i < tool_calls.get_length (); i++) {
                        var tc = tool_calls.get_object_element (i);
                        if (tc == null) continue;
                        var fn_obj = tc.get_object_member ("function");
                        if (fn_obj == null) continue;
                        unowned string? fn_name = fn_obj.get_string_member_with_default ("name", "");
                        if (fn_name == "complete_onboarding") {
                            onboarding_complete = true;
                            break;
                        }
                    }
                }

                /* Show text content if present (only if onboarding is not completing, to avoid double bubbles) */
                if (!onboarding_complete) {
                    var content_node = message.get_member ("content");
                    if (content_node != null && content_node.get_node_type () == Json.NodeType.VALUE) {
                        unowned string? content = content_node.get_string ();
                        if (content != null && content != "") {
                            append_bubble (content, true);
                        }
                    }
                }

                /* Stop when the model is done talking */
                if (finish_reason == "stop" && !onboarding_complete) break;

                /* Process tool calls */
                if (tool_calls_node != null && tool_calls_node.get_node_type () == Json.NodeType.ARRAY) {
                    var tool_calls = tool_calls_node.get_array ();
                    for (uint i = 0; i < tool_calls.get_length (); i++) {
                        var tc = tool_calls.get_object_element (i);
                        if (tc == null) continue;

                        unowned string? tc_id = tc.get_string_member_with_default ("id", "call_0");
                        var fn_obj = tc.get_object_member ("function");
                        if (fn_obj == null) continue;

                        unowned string? fn_name = fn_obj.get_string_member_with_default ("name", "");
                        unowned string? fn_args = fn_obj.get_string_member_with_default ("arguments", "{}");

                        string result = execute_onboarding_tool (fn_name, fn_args);
                        push_tool_result_json (tc_id, result);
                    }
                }

                if (onboarding_complete) {
                    finish_button.visible = false;
                    chat_continue_button.visible = true;

                    /* Format role in Spanish for natural phrasing */
                    string role_es = profile_role;
                    string role_lower = profile_role.down ();
                    if (role_lower.contains ("coding") || role_lower.contains ("programaci")) {
                        role_es = "coding assistant";
                    } else if (role_lower.contains ("productivity") || role_lower.contains ("productividad")) {
                        role_es = "asistente de productividad";
                    } else if (role_lower.contains ("creative") || role_lower.contains ("creativ")) {
                        role_es = "compañera creativa";
                    } else if (role_lower.contains ("general")) {
                        role_es = "asistente de ayuda general";
                    }

                    string final_msg = "Genial, %s — ya estoy lista como tu %s. Me encantará ayudarte por aquí. Por favor presiona el botón Continuar para terminar la configuración.".printf (profile_user_name, role_es);
                    append_bubble (final_msg, true);
                    break;
                }

                /* Feed tool results back to the model */
                typing_box.visible = true;
            }

        } catch (Error e) {
            typing_box.visible = false;
            string err_msg = e.message;
            if (err_msg.contains ("usage_limit_reached") || err_msg.contains ("usage limit")) {
                append_error_bubble (_("Límite de uso alcanzado en tu cuenta de ChatGPT. Inténtalo más tarde o cambia de cuenta."));
            } else {
                append_error_bubble (_("Error de conexión: %s").printf (err_msg));
            }
        }

        chat_entry.sensitive = true;
        send_button.sensitive = true;
        scroll_to_bottom ();
    }

    /* -- HTTP call to gateway -- */

    private async Json.Object? call_gateway () throws Error {
        var msgs_sb = new GLib.StringBuilder ("[");
        bool first = true;
        foreach (var m in chat_message_jsons) {
            if (!first) msgs_sb.append (",");
            msgs_sb.append (m);
            first = false;
        }
        msgs_sb.append ("]");

        var body = "{\"model\":\"gpt-5.4\",\"max_completion_tokens\":400," +
            "\"session_id\":\"" + onboarding_session_id + "\"," +
            "\"x_client_tools\":true," +
            "\"tool_choice\":\"auto\"," +
            "\"tools\":" + ONBOARDING_TOOLS_JSON + "," +
            "\"messages\":" + msgs_sb.str + "}";

        var soup_msg = new Soup.Message ("POST", "http://127.0.0.1:4389/v1/chat/completions");
        soup_msg.request_headers.set_content_type ("application/json", null);
        soup_msg.set_request_body_from_bytes (
            "application/json",
            new GLib.Bytes ((uint8[]) body.data)
        );

        var response_bytes = yield http_session.send_and_read_async (
            soup_msg, GLib.Priority.DEFAULT, null
        );

        unowned uint8[] raw = response_bytes.get_data ();
        var response_str = (string) raw;

        if (soup_msg.status_code != 200) {
            try {
                var parser = new Json.Parser ();
                parser.load_from_data (response_str, (ssize_t) response_bytes.get_size ());
                var root = parser.get_root ();
                if (root != null && root.get_node_type () == Json.NodeType.OBJECT) {
                    var obj = root.get_object ();
                    var error_node = obj.get_member ("error");
                    if (error_node != null && error_node.get_node_type () == Json.NodeType.OBJECT) {
                        var err_obj = error_node.get_object ();
                        unowned string? err_msg = err_obj.get_string_member_with_default ("message", null);
                        if (err_msg != null && err_msg != "") {
                            throw new GLib.IOError.FAILED (err_msg);
                        }
                    }
                }
            } catch (Error parse_err) {
                // Ignore parse errors, use the raw response body
            }
            throw new GLib.IOError.FAILED (response_str.strip ());
        }

        var parser = new Json.Parser ();
        parser.load_from_data (response_str, (ssize_t) response_bytes.get_size ());
        var root = parser.get_root ();
        if (root == null) return null;
        return root.get_object ();
    }

    /* -- Onboarding tool execution -- */

    private string execute_onboarding_tool (string name, string args_str) {
        try {
            var parser = new Json.Parser ();
            parser.load_from_data (args_str, -1);
            var root = parser.get_root ();
            var obj = (root != null) ? root.get_object () : null;

            switch (name) {
                case "set_assistant_name":
                    var v = (obj != null) ? obj.get_string_member_with_default ("name", "") : "";
                    if (v != "") profile_assistant_name = v;
                    return "ok";
                case "set_user_name":
                    var v = (obj != null) ? obj.get_string_member_with_default ("name", "") : "";
                    if (v != "") profile_user_name = v;
                    return "ok";
                case "set_personality":
                    var v = (obj != null) ? obj.get_string_member_with_default ("vibe", "") : "";
                    if (v != "") profile_personality = v;
                    return "ok";
                case "set_role":
                    var v = (obj != null) ? obj.get_string_member_with_default ("role", "") : "";
                    if (v != "") profile_role = v;
                    return "ok";
                case "complete_onboarding":
                    return "ok";
                default:
                    return "unknown tool: " + name;
            }
        } catch (Error e) {
            return "error: " + e.message;
        }
    }

    /* Append a tool result message to history. */
    private void push_tool_result_json (string call_id, string result) {
        var ec_id = escape_json_string (call_id);
        var ec_result = escape_json_string (result);
        chat_message_jsons.add (
            "{\"role\":\"tool\",\"tool_call_id\":\"" + ec_id + "\",\"content\":\"" + ec_result + "\"}"
        );
    }

    /* Serialize a message Json.Object back to a JSON string for history storage.
       Preserves tool_calls so multi-turn tool use is handled correctly. */
    private string serialize_assistant_message (Json.Object msg) {
        var gen = new Json.Generator ();
        var node = new Json.Node (Json.NodeType.OBJECT);
        node.set_object (msg);
        gen.set_root (node);
        return gen.to_data (null);
    }

    /* -- Provision user and transition to DONE -- */

    private async void finish_onboarding () {
        chat_continue_button.sensitive = false;

        var profile = new Installer.OpenClawOnboardingProfile (
            profile_assistant_name,
            profile_role,
            profile_personality,
            profile_user_name,
            "Be helpful without filler. Take initiative, but ask before destructive or external actions.",
            "This is my personal machine. Help me get productive quickly and keep context organized."
        );

        try {
            OpenClawBootstrap.provision_user (
                created_user,
                selected_provider,
                (selected_provider == "openai-codex" ? chatgpt_profile_json : github_token),
                profile,
                created_user_name,
                created_user_real_name
            );
            try {
                string[] argv = {
                    "/usr/bin/systemctl", "--user", "-M",
                    created_user_name + "@", "restart", "elementary-claw.service",
                    null
                };
                var proc = new Subprocess.newv (argv, SubprocessFlags.NONE);
                proc.wait (null);
            } catch (Error restart_err) {
                message ("Could not restart elementary-claw service: %s", restart_err.message);
            }
        } catch (Error e) {
            message ("Provision error: %s", e.message);
        }

        update_step (Step.DONE);
    }

    /* -- Connection routing & ChatGPT Connection -- */

    private void on_provider_toggled () {
        if (github_radio.active) {
            selected_provider = "github-copilot";
            chatgpt_input_box.visible = false;
            connect_button.label = _("Connect with GitHub");
            connect_button.sensitive = true;
            subtitle_label.label = _("Sign in with GitHub to activate Semantha.");
            device_code_box.visible = false;
        } else if (chatgpt_radio.active) {
            selected_provider = "openai-codex";
            chatgpt_input_box.visible = true;
            connect_button.label = _("Connect ChatGPT");
            subtitle_label.label = _("Connect your ChatGPT subscription to activate Semantha.");
            device_code_box.visible = false;
            on_chatgpt_url_changed ();
        }
    }

    private void on_chatgpt_url_changed () {
        if (selected_provider == "openai-codex") {
            var text = chatgpt_url_entry.text.strip ();
            connect_button.sensitive = (text != "" && text.contains ("/auth/callback"));
        }
    }

    private async void on_connect_clicked () {
        if (selected_provider == "github-copilot") {
            yield start_connect ();
        } else if (selected_provider == "openai-codex") {
            yield start_connect_chatgpt ();
        }
    }

    private string auth_url = "";

    private void on_chatgpt_login_clicked () {
        chatgpt_login_button.sensitive = false;
        status_label.label = _("Abriendo la conexión con ChatGPT…");
        status_label.visible = true;
        update_state (_("Connecting\u2026"), "ai-state-progress");

        begin_chatgpt_subscription.begin ((obj, res) => {
            string error_message = "";
            bool started = false;
            string started_auth_url = "";
            try {
                started_auth_url = begin_chatgpt_subscription.end (res);
                started = true;
            } catch (GLib.Error e) {
                error_message = e.message;
            }

            GLib.Idle.add (() => {
                chatgpt_login_button.sensitive = true;
                if (!started) {
                    status_label.label = error_message;
                    status_label.visible = true;
                    update_state (_("Not connected"), "ai-state-error");
                    return GLib.Source.REMOVE;
                }

                auth_url = started_auth_url;
                chatgpt_url_entry.visible = true;
                chatgpt_url_entry.grab_focus ();
                status_label.label = _("Inicia sesión en ChatGPT y pega aquí la URL completa de redirección.");
                status_label.visible = true;
                verification_uri = auth_url;
                launch_browser ();
                return GLib.Source.REMOVE;
            });
        });
    }

    private async string begin_chatgpt_subscription () throws GLib.Error {
        var msg = new Soup.Message ("POST", "http://127.0.0.1:4389/v1/providers/openai-codex/init");
        msg.request_headers.set_content_type ("application/json", null);
        msg.set_request_body_from_bytes (
            "application/json",
            new GLib.Bytes.take ("{}".data)
        );

        GLib.Bytes response_bytes = yield http_session.send_and_read_async (
            msg, GLib.Priority.DEFAULT, null
        );

        string body = (string) response_bytes.get_data ();
        if (msg.status_code != 200) {
            throw new GLib.IOError.FAILED (
                _("No pude iniciar la conexión con ChatGPT: %s").printf (body.strip ())
            );
        }

        var parser = new Json.Parser ();
        parser.load_from_data (body, -1);
        unowned Json.Object root_obj = parser.get_root ().get_object ();
        return root_obj.get_string_member ("authUrl");
    }

    private async void start_connect_chatgpt () {
        connect_button.sensitive = false;
        spinner.visible = true;
        spinner.start ();
        status_label.label = _("Conectando tu suscripción de ChatGPT\u2026");
        status_label.visible = true;
        update_state (_("Connecting\u2026"), "ai-state-progress");

        var raw_url = chatgpt_url_entry.text.strip ();
        var ok = yield exchange_chatgpt_oauth (raw_url);

        if (!ok) {
            var temp_profile = read_chatgpt_profile_from_auth_store ();
            if (temp_profile != "") {
                ok = true;
            }
        }

        spinner.stop ();
        spinner.visible = false;
        status_label.visible = false;

        if (ok) {
            chatgpt_profile_json = read_chatgpt_profile_from_auth_store ();
            if (chatgpt_profile_json == "") {
                connect_button.sensitive = true;
                status_label.label = _("Error al leer el perfil de ChatGPT.");
                status_label.visible = true;
                update_state (_("Not connected"), "ai-state-error");
                show_connect_error (_("Error de conexión"), _("No se pudo leer el archivo de perfil de ChatGPT guardado."));
                return;
            }

            chatgpt_input_box.visible = false;
            provider_select_box.visible = false;
            update_state (_("Connected"), "ai-state-success");
            update_step (Step.CHAT);
        } else {
            connect_button.sensitive = true;
            status_label.label = _("Could not connect. Verify redirect URL.");
            status_label.visible = true;
            update_state (_("Not connected"), "ai-state-error");
            show_connect_error (_("Unable to connect to ChatGPT"), _("Verify the pasted redirect URL is correct and hasn't expired."));
        }
    }

    private async bool exchange_chatgpt_oauth (string raw_url) {
        var body = "{\"raw_url\":\"" + escape_json_string (raw_url) + "\",\"model\":\"gpt-5.4\"}";
        var soup_msg = new Soup.Message ("POST", "http://127.0.0.1:4389/v1/providers/openai-codex/exchange");
        soup_msg.request_headers.set_content_type ("application/json", null);
        soup_msg.set_request_body_from_bytes (
            "application/json",
            new GLib.Bytes ((uint8[]) body.data)
        );

        try {
            var response_bytes = yield http_session.send_and_read_async (
                soup_msg, GLib.Priority.DEFAULT, null
            );
            var status = soup_msg.get_status ();
            return (status >= 200 && status < 300);
        } catch (Error e) {
            warning ("Error exchanging ChatGPT code: %s", e.message);
            return false;
        }
    }

    private string read_chatgpt_profile_from_auth_store () {
        var path = Path.build_filename (Environment.get_home_dir (), ".openclaw", "agents", "main", "agent", "auth-profiles.json");
        if (!FileUtils.test (path, FileTest.EXISTS)) {
            return "";
        }
        try {
            string contents;
            FileUtils.get_contents (path, out contents);
            var parser = new Json.Parser ();
            parser.load_from_data (contents, -1);
            var root_obj = parser.get_root ().get_object ();
            if (root_obj.has_member ("profiles")) {
                var profiles = root_obj.get_object_member ("profiles");
                if (profiles.has_member ("openai-codex:default")) {
                    var generator = new Json.Generator ();
                    generator.set_root (profiles.get_member ("openai-codex:default"));
                    return generator.to_data (null);
                }
            }
        } catch (Error e) {
            warning ("Error reading ChatGPT profile: %s", e.message);
        }
        return "";
    }


    /* -- Send message (user input) -- */

    private void on_send_message () {
        var text = chat_entry.text.strip ();
        if (text == "") return;
        chat_entry.text = "";

        push_message_json ("user", text);
        append_bubble (text, false);
        ai_turn.begin ();
    }

    /* -- Append a chat message (Nothing-style typographic row) -- */

    private void append_bubble (string text, bool is_ai) {
        var role_label = new Gtk.Label (is_ai ? profile_assistant_name.up () : "YOU") {
            xalign = 0,
            halign = START
        };
        role_label.add_css_class ("ai-msg-role");

        var msg_label = new Gtk.Label (text) {
            wrap = true,
            wrap_mode = Pango.WrapMode.WORD_CHAR,
            xalign = 0,
            halign = START,
            max_width_chars = 44,
            selectable = true
        };
        msg_label.add_css_class (is_ai ? "ai-msg-text-ai" : "ai-msg-text-user");

        var msg_row = new Gtk.Box (VERTICAL, 2) {
            halign = START,
            margin_top = 16,
            margin_start = 4,
            margin_end = 4
        };
        msg_row.add_css_class ("ai-msg-row");
        msg_row.append (role_label);
        msg_row.append (msg_label);

        chat_messages.append (msg_row);
        scroll_to_bottom ();
    }

    private void append_error_bubble (string text) {
        var role_label = new Gtk.Label ("SYSTEM") {
            xalign = 0,
            halign = START
        };
        role_label.add_css_class ("ai-msg-role");
        role_label.add_css_class ("ai-msg-role-error");

        var msg_label = new Gtk.Label (text) {
            wrap = true,
            wrap_mode = Pango.WrapMode.WORD_CHAR,
            xalign = 0,
            halign = START,
            max_width_chars = 44,
            selectable = true
        };
        msg_label.add_css_class ("ai-msg-text-error");

        var msg_row = new Gtk.Box (VERTICAL, 2) {
            halign = START,
            margin_top = 16,
            margin_start = 4,
            margin_end = 4
        };
        msg_row.add_css_class ("ai-msg-row");
        msg_row.append (role_label);
        msg_row.append (msg_label);

        chat_messages.append (msg_row);
        scroll_to_bottom ();
    }

    private void scroll_to_bottom () {
        Idle.add (() => {
            var adj = outer_scroller.vadjustment;
            adj.value = adj.upper - adj.page_size;
            return false;
        });
    }

    /* ------------------------------------------------------------------ */
    /*  State indicator                                                     */
    /* ------------------------------------------------------------------ */

    private void update_state (string text, string css_class) {
        state_label.label = text;
        var dot = state_indicator.get_first_child ();
        if (dot != null) {
            dot.remove_css_class ("ai-state-waiting");
            dot.remove_css_class ("ai-state-progress");
            dot.remove_css_class ("ai-state-success");
            dot.remove_css_class ("ai-state-error");
            dot.add_css_class (css_class);
        }
    }

    /* ------------------------------------------------------------------ */
    /*  Browser launch                                                      */
    /* ------------------------------------------------------------------ */

    private void launch_browser () {
        if (verification_uri == "") return;
        launch_browser_fallback ();
    }

    private void launch_browser_fallback () {
        string? real_user = Environment.get_variable ("SUDO_USER");
        /* Detect running-as-root: check both getuid() AND geteuid().
         * The binary may be setuid (real=user, effective=root) where
         * getuid() returns the user's UID but geteuid() returns 0.
         * Also handle plain sudo where getuid()==0. */
        bool running_as_root = (Posix.getuid () == 0 || Posix.geteuid () == 0);
        bool as_other_user = (real_user != null && real_user != "" && running_as_root);

        /* Browser commands to try, in order.
         * Epiphany on elementary OS is a Flatpak — "epiphany" won't be in PATH.
         * Try "flatpak run org.gnome.Epiphany" first, then native binaries,
         * and xdg-open LAST because it may resolve to Code or another non-browser. */
        string[] browsers = {
            "flatpak run org.gnome.Epiphany",
            "epiphany", "epiphany-browser", "firefox",
            "chromium-browser", "google-chrome", "xdg-open"
        };

        if (!as_other_user) {
            foreach (string b in browsers) {
                try {
                    Process.spawn_command_line_async (b + " " + Shell.quote (verification_uri));
                    return;
                } catch (Error e) {
                    /* try next */
                }
            }
            warning ("No browser found (non-root path)");
            return;
        }

        string? display  = Environment.get_variable ("DISPLAY");
        string? xauth    = Environment.get_variable ("XAUTHORITY");
        string? sudo_uid = Environment.get_variable ("SUDO_UID");

        var env = new StringBuilder ();
        env.append ("DISPLAY=" + (display ?? ":0"));
        if (xauth != null && xauth != "") {
            env.append (" XAUTHORITY=" + xauth);
        }
        if (sudo_uid != null && sudo_uid != "") {
            string runtime = "/run/user/" + sudo_uid;
            env.append (" XDG_RUNTIME_DIR=" + runtime);
            env.append (" DBUS_SESSION_BUS_ADDRESS=unix:path=" + runtime + "/bus");
        }

        foreach (string browser in browsers) {
            string inner = env.str + " " + browser + " " + verification_uri;
            string cmd = "sudo -u " + Shell.quote (real_user)
                         + " bash -c " + Shell.quote (inner);
            try {
                Process.spawn_command_line_async (cmd);
                return;
            } catch (Error e) {
                warning ("spawn failed for %s: %s", browser, e.message);
            }
        }

        warning ("No browser found. User must visit %s manually.", verification_uri);
        show_connect_error (
            _("Could not open web browser"),
            _("Please open a browser manually and visit:\n") + verification_uri
        );
    }

    /* ------------------------------------------------------------------ */
    /*  Error dialog                                                        */
    /* ------------------------------------------------------------------ */

    private void show_connect_error (string primary_text, string? error_message = null) {
        var error_dialog = new Granite.MessageDialog.with_image_from_icon_name (
            primary_text,
            _("Could not complete GitHub sign-in for this account."),
            "dialog-error",
            Gtk.ButtonsType.CLOSE
        ) {
            modal = true,
            transient_for = (Gtk.Window) get_root ()
        };
        if (error_message != null) {
            error_dialog.show_error_details (error_message);
        }
        error_dialog.present ();
        error_dialog.response.connect (error_dialog.destroy);
    }

    /* ------------------------------------------------------------------ */
    /*  Utilities                                                           */
    /* ------------------------------------------------------------------ */

    private static string sanitize_user_text (string? value) {
        return value ?? "";
    }

    private string get_created_user_display_name () {
        var preferred_name = created_user_real_name.strip ();
        if (preferred_name != "") return preferred_name;
        var login_name = created_user_name.strip ();
        if (login_name != "") return login_name;
        return _("User");
    }

    /* ------------------------------------------------------------------ */
    /*  DNA intro animation                                                 */
    /* ------------------------------------------------------------------ */

    private bool on_anim_tick (Gtk.Widget widget, Gdk.FrameClock clock) {
        int cycle = anim_frame;
        double speed = 0;

        if (cycle < 180) {
            double p = (double) cycle / 180.0;
            speed = 0.03 + (0.12 - 0.03) * ease_in_out (p);
        } else if (cycle < 300) {
            double p = (double)(cycle - 180) / 120.0;
            speed = 0.12 + (0.32 - 0.12) * ease_in_out (p);
        } else if (cycle < 400) {
            speed = 0.32;
        } else if (cycle < 490) {
            double p = (double)(cycle - 400) / 90.0;
            speed = 0.32 * (1.0 - ease_out (p));
        }

        anim_phase += speed;
        anim_frame++;
        dna_canvas.queue_draw ();

        if (anim_frame >= 670) {
            tick_id = 0;
            Idle.add (() => {
                update_step (Step.PRESENTATION);
                return false;
            });
            return false;
        }
        return true;
    }

    private void draw_dna (Gtk.DrawingArea area, Cairo.Context cr, int width, int height) {
        double W = (double) width;
        double H = (double) height;
        double CX = W / 2.0;
        double CY = H / 2.0;
        double sc = Math.fmin (W / 680.0, H / 320.0);

        int cycle = anim_frame;
        double morph_p = 0, stretch_p = 0;

        if (cycle < 180) {
            double p = (double) cycle / 180.0;
            stretch_p = ease_in_out (p) * 0.25;
        } else if (cycle < 300) {
            double p = (double)(cycle - 180) / 120.0;
            stretch_p = 0.25 + ease_in_out (p) * 0.45;
        } else if (cycle < 400) {
            double p = (double)(cycle - 300) / 100.0;
            stretch_p = 0.70 + p * 0.30;
        } else if (cycle < 490) {
            double p = (double)(cycle - 400) / 90.0;
            stretch_p = 1.0 - ease_in_out (p);
            morph_p = p;
        } else {
            stretch_p = 0;
            morph_p = 1.0;
        }

        cr.set_source_rgb (196.0 / 255.0, 76.0 / 255.0, 53.0 / 255.0);
        cr.paint ();

        int N = 300;
        double AMP    = (44.0 + 71.0 * stretch_p) * sc;
        double THICK  = (12.0 + 5.0 * stretch_p) * sc;
        double FREQ   = 2.0;
        double R      = 78.0 * sc;
        double margin = 20.0 * sc;
        int max_segs  = 2 * (N - 1);
        int seg_count = 0;

        double[] seg_x0 = new double[max_segs];
        double[] seg_y0 = new double[max_segs];
        double[] seg_x1 = new double[max_segs];
        double[] seg_y1 = new double[max_segs];
        double[] seg_z  = new double[max_segs];
        double[] seg_th = new double[max_segs];

        for (int r = 0; r < 2; r++) {
            double po = r * Math.PI;
            for (int i = 0; i < N - 1; i++) {
                double s0 = (double) i / (N - 1);
                double s1 = (double)(i + 1) / (N - 1);

                double hx0 = margin + s0 * (W - 2.0 * margin);
                double hx1 = margin + s1 * (W - 2.0 * margin);
                double a0  = FREQ * Math.PI * 2.0 * s0 + anim_phase + po;
                double a1  = FREQ * Math.PI * 2.0 * s1 + anim_phase + po;
                double hy0 = CY + AMP * Math.sin (a0);
                double hy1 = CY + AMP * Math.sin (a1);
                double hz0 = Math.cos (a0);
                double hz1 = Math.cos (a1);

                double ca0 = s0 * Math.PI * 2.0 - Math.PI / 2.0 + po;
                double ca1 = s1 * Math.PI * 2.0 - Math.PI / 2.0 + po;
                double cx0 = CX + R * Math.cos (ca0);
                double cy0 = CY + R * Math.sin (ca0);
                double cx1 = CX + R * Math.cos (ca1);
                double cy1 = CY + R * Math.sin (ca1);
                double cz0 = Math.sin (ca0 + anim_phase * 0.08);
                double cz1 = Math.sin (ca1 + anim_phase * 0.08);

                double mp = ease_in_out (morph_p);
                double x0 = hx0 + (cx0 - hx0) * mp;
                double y0 = hy0 + (cy0 - hy0) * mp;
                double x1 = hx1 + (cx1 - hx1) * mp;
                double y1 = hy1 + (cy1 - hy1) * mp;
                double z0 = hz0 + (cz0 - hz0) * mp;
                double z1 = hz1 + (cz1 - hz1) * mp;
                double z_avg = (z0 + z1) / 2.0;
                double th = THICK * (0.45 + 0.55 * Math.fabs (z_avg));

                seg_x0[seg_count] = x0;
                seg_y0[seg_count] = y0;
                seg_x1[seg_count] = x1;
                seg_y1[seg_count] = y1;
                seg_z[seg_count]  = z_avg;
                seg_th[seg_count] = th;
                seg_count++;
            }
        }

        int[] order = new int[seg_count];
        for (int i = 0; i < seg_count; i++) order[i] = i;
        for (int i = 1; i < seg_count; i++) {
            int key = order[i];
            double kz = seg_z[key];
            int j = i - 1;
            while (j >= 0 && seg_z[order[j]] > kz) {
                order[j + 1] = order[j];
                j--;
            }
            order[j + 1] = key;
        }

        for (int i = 0; i < seg_count; i++) {
            int idx = order[i];
            double dx = seg_x1[idx] - seg_x0[idx];
            double dy = seg_y1[idx] - seg_y0[idx];
            double len = Math.sqrt (dx * dx + dy * dy);
            if (len < 0.001) len = 1.0;
            double nx = -dy / len;
            double ny = dx / len;
            double b  = (seg_z[idx] + 1.0) / 2.0;
            double alpha = 0.3 + 0.7 * b;
            double t = seg_th[idx];

            double p0tx = seg_x0[idx] + nx * t, p0ty = seg_y0[idx] + ny * t;
            double p0bx = seg_x0[idx] - nx * t, p0by = seg_y0[idx] - ny * t;
            double p1tx = seg_x1[idx] + nx * t, p1ty = seg_y1[idx] + ny * t;
            double p1bx = seg_x1[idx] - nx * t, p1by = seg_y1[idx] - ny * t;

            cr.move_to (p0tx, p0ty);
            cr.line_to (p1tx, p1ty);
            cr.line_to (p1bx, p1by);
            cr.line_to (p0bx, p0by);
            cr.close_path ();
            cr.set_source_rgba (
                (175.0 + 55.0 * b) / 255.0,
                (130.0 + 65.0 * b) / 255.0,
                (115.0 + 60.0 * b) / 255.0,
                alpha
            );
            cr.fill ();

            if (seg_z[idx] > 0.1) {
                double mx0 = (p0tx + p0bx) / 2.0, my0 = (p0ty + p0by) / 2.0;
                double mx1 = (p1tx + p1bx) / 2.0, my1 = (p1ty + p1by) / 2.0;
                cr.move_to (p0tx, p0ty);
                cr.line_to (p1tx, p1ty);
                cr.line_to (mx1, my1);
                cr.line_to (mx0, my0);
                cr.close_path ();
                cr.set_source_rgba (1.0, 225.0 / 255.0, 215.0 / 255.0, seg_z[idx] * 0.5);
                cr.fill ();
            }
        }
    }

    private static double ease_in_out (double x) {
        if (x < 0.5) return 4.0 * x * x * x;
        return 1.0 - Math.pow (-2.0 * x + 2.0, 3.0) / 2.0;
    }

    private static double ease_out (double x) {
        return 1.0 - Math.pow (1.0 - x, 3.0);
    }
}
